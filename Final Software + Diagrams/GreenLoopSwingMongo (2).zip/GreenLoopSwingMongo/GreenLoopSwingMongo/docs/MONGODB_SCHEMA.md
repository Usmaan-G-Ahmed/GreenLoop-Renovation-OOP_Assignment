# MongoDB Schema Used in GreenLoop

MongoDB is flexible, but this project keeps a clean structure using separate collections.

## `products`

```json
{
  "_id": "ObjectId",
  "code": "BIO-WRAP-01",
  "name": "Biodegradable Wrap",
  "category": "Wrapping",
  "unitPrice": 850.00,
  "ecoRating": 5
}
```

## `clients`

```json
{
  "_id": "ObjectId",
  "name": "Island Fresh Retail",
  "email": "client1@example.com",
  "phone": "0771234567",
  "address": "Colombo"
}
```

## `inventory`

```json
{
  "_id": "ObjectId",
  "productId": "product ObjectId as string",
  "productName": "Biodegradable Wrap",
  "quantityOnHand": 40,
  "reorderLevel": 20,
  "supplier": "Eco Lanka Suppliers",
  "lastStockInDate": "Date"
}
```

## `delivery_agents`

```json
{
  "_id": "ObjectId",
  "name": "Nimal Perera",
  "email": "agent1@example.com",
  "phone": "0711111111",
  "vehicleNumber": "WP-CAB-1234",
  "vehicleType": "Van"
}
```

## `orders`

```json
{
  "_id": "ObjectId",
  "clientId": "client ObjectId as string",
  "clientName": "Island Fresh Retail",
  "items": [
    {
      "productId": "product ObjectId as string",
      "productName": "Recycled Box Medium",
      "quantity": 10,
      "unitPrice": 120.00,
      "lineTotal": 1200.00
    }
  ],
  "totalAmount": 1200.00,
  "status": "CREATED / ASSIGNED / DISPATCHED / DELIVERED",
  "assignedAgentId": "agent ObjectId as string",
  "assignedAgentName": "Nimal Perera",
  "deliveryDate": "Date",
  "createdAt": "Date"
}
```

## `email_logs`

```json
{
  "_id": "ObjectId",
  "recipientType": "CLIENT / DELIVERY_AGENT",
  "recipientEmail": "client1@example.com",
  "subject": "GreenLoop Order Dispatched",
  "body": "email body",
  "status": "SENT / DEMO_LOGGED / FAILED",
  "createdAt": "Date"
}
```
