# Short Viva Speech

Our project is a Java Swing desktop application for GreenLoop, an eco-friendly packaging supply company. The main problem is that GreenLoop currently uses handwritten logs, WhatsApp messages and Google Sheets. Our system replaces those manual methods with one desktop application connected to MongoDB.

The project is divided into seven main UI tabs. Product management handles packaging products with price and eco-rating. Client management stores retail client details. Inventory management tracks stock quantity, reorder levels and suppliers. Delivery agent management stores delivery staff and vehicle details. Order processing allows staff to create client orders, add products and automatically calculate the total. Delivery assignment allows staff to assign an agent, set a delivery date and update order status. The report section generates monthly revenue summaries, low-stock alerts and email logs.

We used MongoDB because the system stores different types of business records as flexible documents. In the Java code, each module has a model class, a repository class and a Swing panel. The model represents the data, the repository handles MongoDB CRUD operations, and the panel handles the user interface.

The email notification feature can send real emails if SMTP settings are configured. If SMTP is not configured for the viva, the system still records the email in the MongoDB `email_logs` collection, so we can demonstrate that the notification process works.

Overall, this system automates product, client, inventory, order, delivery, reporting and notification processes for GreenLoop.
