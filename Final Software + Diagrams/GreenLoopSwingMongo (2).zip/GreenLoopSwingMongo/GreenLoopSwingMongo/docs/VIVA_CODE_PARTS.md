# GreenLoop Viva Code Explanation by 7 Members

Use this file to divide the explanation during the viva. Each member can open their assigned Java files and explain the purpose, main methods, and MongoDB collection used.

---

## Member 1 - SA25610601

### Tasks
- Task 1: Manage Product Catalogue
- Task 9: Send Email Notifications to Delivery Agents

### Files
- `src/main/java/com/greenloop/ui/ProductPanel.java`
- `src/main/java/com/greenloop/repository/ProductRepository.java`
- `src/main/java/com/greenloop/model/Product.java`
- `src/main/java/com/greenloop/service/EmailService.java`

### Viva points
- `ProductPanel` creates the Swing UI for product code, name, category, price and eco-rating.
- Add, update and delete buttons call repository methods.
- `ProductRepository` saves product documents into MongoDB collection `products`.
- Delivery agent email is handled by `EmailService.sendDeliveryAssignmentEmail()`.
- If SMTP is not configured, the email is saved to `email_logs` as `DEMO_LOGGED`.

---

## Member 2 - SA25610600

### Tasks
- Task 2: Manage Clients
- Task 8: Send Email Notifications to Clients

### Files
- `src/main/java/com/greenloop/ui/ClientPanel.java`
- `src/main/java/com/greenloop/repository/ClientRepository.java`
- `src/main/java/com/greenloop/model/Client.java`
- `src/main/java/com/greenloop/service/EmailService.java`

### Viva points
- `ClientPanel` collects client name, email, phone and address.
- Validation checks empty fields and a simple email format.
- `ClientRepository` performs CRUD operations in the `clients` collection.
- Client dispatch email is sent/logged using `sendClientDispatchEmail()`.

---

## Member 3 - SA25610598

### Tasks
- Task 3: Manage Stock / Inventory

### Files
- `src/main/java/com/greenloop/ui/InventoryPanel.java`
- `src/main/java/com/greenloop/repository/InventoryRepository.java`
- `src/main/java/com/greenloop/model/InventoryItem.java`

### Viva points
- Inventory is connected to products using `productId`.
- It stores quantity on hand, reorder level, supplier and last stock-in date.
- `Stock-In` adds new quantity to the existing quantity.
- Low stock means `quantityOnHand <= reorderLevel`.

---

## Member 4 - SA25610458

### Tasks
- Task 4: Manage Delivery Agents

### Files
- `src/main/java/com/greenloop/ui/DeliveryAgentPanel.java`
- `src/main/java/com/greenloop/repository/DeliveryAgentRepository.java`
- `src/main/java/com/greenloop/model/DeliveryAgent.java`

### Viva points
- Delivery agents have name, email, phone, vehicle number and vehicle type.
- Data is displayed in a JTable.
- The repository saves data to `delivery_agents` collection.
- These agents are later used in the delivery assignment panel.

---

## Member 5 - SA25610569

### Tasks
- Task 5: Process Client Orders

### Files
- `src/main/java/com/greenloop/ui/OrderPanel.java`
- `src/main/java/com/greenloop/repository/OrderRepository.java`
- `src/main/java/com/greenloop/model/Order.java`
- `src/main/java/com/greenloop/model/OrderItem.java`

### Viva points
- A client is selected, then products are added as order items.
- The total is calculated using quantity times unit price.
- Before saving, the code checks inventory availability.
- After saving an order, stock is reduced.
- Orders are stored in the `orders` collection with status `CREATED`.

---

## Member 6 - SA25610430

### Tasks
- Task 6: Assign Delivery Agents to Orders

### Files
- `src/main/java/com/greenloop/ui/DeliveryAssignmentPanel.java`
- `src/main/java/com/greenloop/repository/OrderRepository.java`

### Viva points
- Open orders are loaded from MongoDB.
- The user selects an order, selects an agent and enters a delivery date.
- `assignAgent()` updates the order with agent id, agent name, delivery date and status `ASSIGNED`.
- The same panel can mark orders as `DISPATCHED` or `DELIVERED`.

---

## Member 7 - SA25610567

### Tasks
- Task 7: Generate Monthly Sales & Inventory Reports

### Files
- `src/main/java/com/greenloop/ui/ReportPanel.java`
- `src/main/java/com/greenloop/service/ReportService.java`
- `src/main/java/com/greenloop/repository/EmailLogRepository.java`

### Viva points
- The report panel accepts year and month.
- `ReportService` filters orders by date range.
- Monthly revenue is the sum of order totals.
- Low-stock products are shown using the inventory collection.
- Email logs show whether notification emails were sent or saved as demo logs.
- Sales report can be exported as CSV.

---

## Shared files all members should know

- `GreenLoopApp.java`: Application starting point.
- `MainFrame.java`: Main Swing window and tabs.
- `DatabaseConnection.java`: MongoDB connection class.
- `Style.java`: Common UI colors, buttons, tables and form design.
- `ValidationUtil.java`: Input validation helper.
- `DateUtil.java`: Date conversion and formatting helper.

## MongoDB explanation for viva

This project uses MongoDB because the company has different types of records such as products, clients, orders and email logs. MongoDB stores each record as a document. In the code, every repository converts Java objects into MongoDB `Document` objects before saving.

Example:

- Java class: `Product`
- Repository: `ProductRepository`
- MongoDB collection: `products`
- UI panel: `ProductPanel`

Flow:

`Swing form input -> Model object -> Repository -> MongoDB collection -> JTable display`
