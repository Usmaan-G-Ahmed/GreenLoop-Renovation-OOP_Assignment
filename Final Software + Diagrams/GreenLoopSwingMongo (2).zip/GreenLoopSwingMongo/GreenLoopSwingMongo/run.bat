@echo off
REM Start MongoDB before running this file.
REM Default DB URI: mongodb://localhost:27017
mvn clean compile exec:java
pause
