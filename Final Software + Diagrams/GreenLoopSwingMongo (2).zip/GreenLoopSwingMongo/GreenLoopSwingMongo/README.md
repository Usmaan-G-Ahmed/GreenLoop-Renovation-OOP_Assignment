# GreenLoop Java Swing + MongoDB Project

This is a full Java Swing desktop application for the GreenLoop group project viva. It uses MongoDB as the database and Maven for dependencies.

## Main features implemented

1. Manage Product Catalogue: add, update, remove packaging products with pricing and eco-rating.
2. Manage Clients: add, update, remove retail clients and contact details.
3. Manage Stock / Inventory: track quantity on hand, reorder levels and stock-in from suppliers.
4. Manage Delivery Agents: add, update, remove delivery staff and vehicle details.
5. Process Client Orders: create orders, add products, calculate totals and reduce stock.
6. Assign Delivery Agents to Orders: schedule and track delivery status.
7. Generate Monthly Sales & Inventory Reports: revenue summary, low-stock alerts and email logs.
8. Send Email Notifications to Clients when orders are dispatched.
9. Send Email Notifications to Delivery Agents when deliveries are assigned.

## Database

Database name: `greenloop_db`

Collections used:

- `products`
- `clients`
- `inventory`
- `delivery_agents`
- `orders`
- `email_logs`

Default MongoDB URI: `mongodb://localhost:27017`

You can override it using an environment variable:

```bash
GREENLOOP_MONGO_URI=mongodb://localhost:27017
```

## How to run

### Requirements

- Java JDK 17 or newer
- Maven
- MongoDB Community Server running locally

### Run command

Open the project folder in terminal and run:

```bash
mvn clean compile exec:java
```

Or on Windows double click/run:

```text
run.bat
```

The app inserts sample data automatically only when the database collections are empty. This helps you demonstrate the viva quickly.

## Optional real email setup

If SMTP is not configured, the app still works. Email messages are saved in the `email_logs` collection with status `DEMO_LOGGED`.

To send real emails, set these environment variables before running:

```bash
GREENLOOP_SMTP_HOST=smtp.gmail.com
GREENLOOP_SMTP_PORT=587
GREENLOOP_SMTP_USERNAME=your_email@gmail.com
GREENLOOP_SMTP_PASSWORD=your_app_password
GREENLOOP_FROM_EMAIL=your_email@gmail.com
```

For Gmail, use an App Password, not your normal Gmail password.

## 7-member viva code allocation

| Member IT Number | Project tasks | Main code files to explain |
|---|---|---|
| SA25610601 | 1 and 9: Product catalogue + email to delivery agents | `ProductPanel.java`, `ProductRepository.java`, `Product.java`, `EmailService.java` delivery-agent method |
| SA25610600 | 2 and 8: Client management + email to clients | `ClientPanel.java`, `ClientRepository.java`, `Client.java`, `EmailService.java` client-dispatch method |
| SA25610598 | 3: Stock / inventory | `InventoryPanel.java`, `InventoryRepository.java`, `InventoryItem.java` |
| SA25610458 | 4: Delivery agents | `DeliveryAgentPanel.java`, `DeliveryAgentRepository.java`, `DeliveryAgent.java` |
| SA25610569 | 5: Process client orders | `OrderPanel.java`, `OrderRepository.java`, `Order.java`, `OrderItem.java` |
| SA25610430 | 6: Assign delivery agents to orders | `DeliveryAssignmentPanel.java`, assignment method in `OrderRepository.java` |
| SA25610567 | 7: Monthly sales and inventory reports | `ReportPanel.java`, `ReportService.java`, `EmailLogRepository.java` |

## Simple viva demonstration flow

1. Start MongoDB.
2. Run the app.
3. Open Products and add a new product.
4. Open Clients and add a client.
5. Open Inventory and create inventory for the product.
6. Open Delivery Agents and add an agent.
7. Open Orders, select client/product, enter quantity, add item, then create order.
8. Open Delivery Assignment, select the order and agent, assign the agent. The app logs/sends delivery-agent email.
9. Mark the order as dispatched. The app logs/sends client email.
10. Open Reports and generate the monthly report. Show revenue, low stock and email logs.
