#!/usr/bin/env bash
# Start MongoDB before running this file.
# Default DB URI: mongodb://localhost:27017
mvn clean compile exec:java
