package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Graphics;
import java.awt.Insets;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

public final class Style {

    // ================= COLORS =================

    // Deep obsidian-green base
    public static final Color BACKGROUND      = new Color(10,  15,  11);   // #0a0f0b
    public static final Color CARD            = new Color(14,  25,  16);   // #0e1910
    public static final Color CARD_HOVER      = new Color(18,  31,  19);   // #121f13

    // Electric emerald accents
    public static final Color GREEN           = new Color(74, 222, 123);   // #4ade7b  — primary accent
    public static final Color GREEN_DARK      = new Color(22,  43,  24);   // #162b18  — muted fill
    public static final Color GREEN_MID       = new Color(61, 184,  74);   // #3db84a  — secondary action

    // Text
    public static final Color TEXT            = new Color(240, 247, 240);  // #f0f7f0  — primary
    public static final Color TEXT_SECONDARY  = new Color( 90, 122,  94);  // #5a7a5e  — muted

    // Borders
    public static final Color BORDER          = new Color( 30,  53,  32);  // #1e3520
    public static final Color BORDER_SUBTLE   = new Color( 22,  43,  24);  // #162b18
    public static final Color BORDER_ACCENT   = new Color( 42,  92,  46);  // #2a5c2e

    // Status bar / chrome
    public static final Color CHROME          = new Color(  8,  13,   9);  // #080d09

    // ================= FONTS =================

    public static final Font TITLE_FONT    = new Font("Segoe UI", Font.BOLD,  24);
    public static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font NORMAL_FONT   = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font BOLD_FONT     = new Font("Segoe UI", Font.BOLD,  13);
    public static final Font CARD_TITLE    = new Font("Segoe UI", Font.BOLD,  20);
    public static final Font MONO_FONT     = new Font("Consolas",  Font.PLAIN, 12);

    private Style() {}

    // ================= PAGE =================

    public static JPanel page(String title, String description) {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BACKGROUND);
        panel.setBorder(new EmptyBorder(28, 28, 28, 28));

        JLabel header = new JLabel(
            "<html>" +
            "<div style='font-size:22px;font-weight:bold;color:#f0f7f0;letter-spacing:-0.3px;'>"
                + title +
            "</div>" +
            "<div style='font-size:12px;color:#5a7a5e;padding-top:5px;font-family:monospace;text-transform:uppercase;letter-spacing:0.5px;'>"
                + description +
            "</div></html>"
        );
        panel.add(header, BorderLayout.NORTH);
        return panel;
    }

    // ================= CARD =================

    public static JPanel card() {
        JPanel card = new JPanel(new BorderLayout(15, 15));
        card.setBackground(CARD);
        card.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                new EmptyBorder(20, 20, 20, 20)
            )
        );
        return card;
    }

    // ================= FORM PANEL =================

    public static JPanel formPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(CARD);
        return panel;
    }

    // ================= FORM FIELD =================

    public static void addField(JPanel panel, int row, String label, Component field) {
        GridBagConstraints labelGc = new GridBagConstraints();
        labelGc.gridx = 0;
        labelGc.gridy = row;
        labelGc.anchor = GridBagConstraints.WEST;
        labelGc.insets = new Insets(10, 5, 10, 14);

        JLabel jLabel = new JLabel(label);
        jLabel.setFont(MONO_FONT);
        jLabel.setForeground(TEXT_SECONDARY);
        panel.add(jLabel, labelGc);

        GridBagConstraints fieldGc = new GridBagConstraints();
        fieldGc.gridx = 1;
        fieldGc.gridy = row;
        fieldGc.weightx = 1;
        fieldGc.fill = GridBagConstraints.HORIZONTAL;
        fieldGc.insets = new Insets(10, 5, 10, 5);
        panel.add(field, fieldGc);
    }

    // ================= TEXT FIELD =================

    public static JTextField textField() {
        JTextField field = new JTextField(18);
        field.setFont(NORMAL_FONT);
        field.setForeground(TEXT);
        field.setBackground(new Color(12, 20, 13));
        field.setCaretColor(GREEN);
        field.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                new EmptyBorder(9, 12, 9, 12)
            )
        );
        return field;
    }

    // ================= BUTTONS =================
    //
    // setContentAreaFilled(false) + paintComponent override is REQUIRED:
    // the system L&F (UIManager.getSystemLookAndFeel) ignores setBackground()
    // on JButton. We paint the fill ourselves so colours are always respected.

    public static JButton primaryButton(String text) {
        final Color fill   = GREEN;
        final Color border = GREEN;
        final Color hover  = new Color(100, 230, 140);
        final Color fg     = new Color(8, 14, 9);
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(getModel().isRollover() ? hover : fill);
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setForeground(fg);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(border, 1),
            new EmptyBorder(9, 20, 9, 20)
        ));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(160, 40));
        return b;
    }

    public static JButton secondaryButton(String text) {
        final Color fill   = new Color(14, 25, 16);
        final Color border = BORDER_ACCENT;
        final Color hover  = new Color(20, 38, 22);
        final Color fg     = GREEN_MID;
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(getModel().isRollover() ? hover : fill);
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        b.setForeground(fg);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(border, 1),
            new EmptyBorder(9, 20, 9, 20)
        ));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(160, 40));
        return b;
    }

    public static JButton dangerButton(String text) {
        final Color fill   = new Color(38, 14, 14);
        final Color border = new Color(90, 28, 28);
        final Color hover  = new Color(55, 18, 18);
        final Color fg     = new Color(240, 100, 100);
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(getModel().isRollover() ? hover : fill);
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        b.setForeground(fg);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(border, 1),
            new EmptyBorder(9, 20, 9, 20)
        ));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(160, 40));
        return b;
    }

    // ================= TABLE =================

    public static JScrollPane tableScroll(JTable table) {
        final Color HEADER_BG = new Color(12, 20, 13);
        final Color HEADER_FG = new Color(90, 122, 94);

        table.setFont(NORMAL_FONT);
        table.setForeground(TEXT);
        table.setBackground(CARD);
        table.setRowHeight(36);
        table.setGridColor(BORDER_SUBTLE);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(22, 43, 24));
        table.setSelectionForeground(GREEN);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setFillsViewportHeight(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Force header colours — system L&F overrides setBackground on JTableHeader
        // so we use a custom cell renderer just like we do for buttons.
        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(0, 36));
        header.setFont(MONO_FONT);
        header.setOpaque(true);
        header.setBackground(HEADER_BG);
        header.setForeground(HEADER_FG);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean isSelected,
                    boolean hasFocus, int row, int col) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(
                        t, value, isSelected, hasFocus, row, col);
                lbl.setFont(MONO_FONT);
                lbl.setForeground(HEADER_FG);
                lbl.setBackground(HEADER_BG);
                lbl.setOpaque(true);
                lbl.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER),
                    new EmptyBorder(0, 12, 0, 12)
                ));
                lbl.setHorizontalAlignment(SwingConstants.LEFT);
                return lbl;
            }
        });

        // Cell renderer
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean isSelected,
                    boolean hasFocus, int row, int col) {
                super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, col);
                setOpaque(true);
                setBackground(isSelected ? new Color(22, 43, 24) : (row % 2 == 0 ? CARD : new Color(16, 28, 17)));
                setForeground(isSelected ? GREEN : TEXT);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                return this;
            }
        };
        renderer.setHorizontalAlignment(SwingConstants.LEFT);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER, 1));
        scrollPane.getViewport().setBackground(CARD);
        scrollPane.setBackground(CARD);
        return scrollPane;
    }

    // ================= TABLE HELPERS =================

    /**
     * Hides a column by index (e.g. UUID id columns).
     * Must be called AFTER Style.tableScroll() so the column model is set up.
     */
    public static void hideColumn(JTable table, int colIndex) {
        table.getColumnModel().getColumn(colIndex).setMinWidth(0);
        table.getColumnModel().getColumn(colIndex).setMaxWidth(0);
        table.getColumnModel().getColumn(colIndex).setWidth(0);
        table.getColumnModel().getColumn(colIndex).setPreferredWidth(0);
    }

    // ================= COMBO BOX =================
    // JComboBox also ignores setBackground under system L&F.
    // Call Style.styleComboBox(myCombo) right after creating it.

    public static <T> void styleComboBox(JComboBox<T> combo) {
        final Color BG     = new Color(12, 20, 13);
        final Color FG     = TEXT;
        final Color BORDER_C = BORDER;

        combo.setBackground(BG);
        combo.setForeground(FG);
        combo.setFont(NORMAL_FONT);
        combo.setOpaque(true);
        combo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_C, 1),
            new EmptyBorder(2, 8, 2, 4)
        ));

        // Override the UI so L&F cannot repaint its own chrome
        combo.setUI(new BasicComboBoxUI() {
            @Override protected JButton createArrowButton() {
                JButton arrow = new JButton("▾") {
                    @Override protected void paintComponent(Graphics g) {
                        g.setColor(new Color(14, 25, 16));
                        g.fillRect(0, 0, getWidth(), getHeight());
                        super.paintComponent(g);
                    }
                };
                arrow.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                arrow.setForeground(GREEN_MID);
                arrow.setContentAreaFilled(false);
                arrow.setOpaque(false);
                arrow.setFocusPainted(false);
                arrow.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, BORDER_C));
                return arrow;
            }
        });

        // Style the dropdown list
        combo.setRenderer(new ListCellRenderer<T>() {
            private final JLabel lbl = new JLabel();
            @Override
            public Component getListCellRendererComponent(
                    JList<? extends T> list, T value,
                    int index, boolean isSelected, boolean cellHasFocus) {
                lbl.setText(value == null ? "" : value.toString());
                lbl.setFont(NORMAL_FONT);
                lbl.setOpaque(true);
                lbl.setBackground(isSelected ? new Color(22, 43, 24) : BG);
                lbl.setForeground(isSelected ? GREEN : FG);
                lbl.setBorder(new EmptyBorder(8, 12, 8, 12));
                return lbl;
            }
        });

        // Force editor component (the text part) to also be dark
        if (combo.getEditor() != null && combo.getEditor().getEditorComponent() instanceof JTextField) {
            JTextField editor = (JTextField) combo.getEditor().getEditorComponent();
            editor.setBackground(BG);
            editor.setForeground(FG);
            editor.setFont(NORMAL_FONT);
            editor.setCaretColor(GREEN);
            editor.setBorder(new EmptyBorder(0, 4, 0, 4));
        }
    }

    // ================= TABBED PANE =================
    // JTabbedPane ignores setBackground/setForeground under system L&F.
    // We override UIManager keys scoped to this pane via a custom UI delegate.

    public static JTabbedPane tabbedPane() {
        // Set UIManager defaults for tabs — these are global but standard practice
        UIManager.put("TabbedPane.selected",            CARD);
        UIManager.put("TabbedPane.background",          BACKGROUND);
        UIManager.put("TabbedPane.foreground",          TEXT_SECONDARY);
        UIManager.put("TabbedPane.selectedForeground",  GREEN);
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0));
        UIManager.put("TabbedPane.tabInsets",           new Insets(8, 16, 8, 16));
        UIManager.put("TabbedPane.focus",               BACKGROUND);
        UIManager.put("TabbedPane.darkShadow",          BORDER);
        UIManager.put("TabbedPane.shadow",              BORDER_SUBTLE);
        UIManager.put("TabbedPane.light",               BORDER);
        UIManager.put("TabbedPane.highlight",           BORDER_ACCENT);
        UIManager.put("TabbedPane.tabAreaBackground",   BACKGROUND);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(BACKGROUND);
        tabs.setForeground(TEXT_SECONDARY);
        tabs.setFont(MONO_FONT);
        tabs.setBorder(BorderFactory.createLineBorder(BORDER, 1));
        tabs.setOpaque(true);
        return tabs;
    }
}