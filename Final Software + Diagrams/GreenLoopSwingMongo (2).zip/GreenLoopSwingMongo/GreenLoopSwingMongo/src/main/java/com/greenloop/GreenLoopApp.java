package com.greenloop;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.service.DemoDataService;
import com.greenloop.ui.MainFrame;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class GreenLoopApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }

            if (!DatabaseConnection.testConnection()) {
                JOptionPane.showMessageDialog(null,
                        "MongoDB connection failed.\n\nStart MongoDB first, then run the app again.\nDefault URI: mongodb://localhost:27017\nOptional env: GREENLOOP_MONGO_URI",
                        "Database Connection Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            new DemoDataService().insertSampleDataIfEmpty();
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
