package com.greenloop.util;

import java.text.NumberFormat;
import java.util.Locale;

public final class MoneyUtil {
    private static final NumberFormat MONEY = NumberFormat.getCurrencyInstance(Locale.US);

    private MoneyUtil() {
    }

    public static String format(double amount) {
        return MONEY.format(amount);
    }
}
