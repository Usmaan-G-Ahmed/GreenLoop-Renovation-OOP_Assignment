package com.greenloop.model;

public class DeliveryAgent {
    private String id;
    private String name;
    private String email;
    private String phone;
    private String vehicleNumber;
    private String vehicleType;

    public DeliveryAgent() {
    }

    public DeliveryAgent(String id, String name, String email, String phone, String vehicleNumber, String vehicleType) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.vehicleNumber = vehicleNumber;
        this.vehicleType = vehicleType;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }
    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    @Override
    public String toString() {
        return name + " - " + vehicleNumber;
    }
}
