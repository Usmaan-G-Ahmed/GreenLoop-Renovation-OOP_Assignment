package com.greenloop.repository;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.model.InventoryItem;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.expr;

public class InventoryRepository {
    private final MongoCollection<Document> inventory = DatabaseConnection.getDatabase().getCollection("inventory");

    public String insert(InventoryItem item) {
        Document doc = toDocument(item);
        inventory.insertOne(doc);
        return doc.getObjectId("_id").toHexString();
    }

    public void update(InventoryItem item) {
        inventory.replaceOne(eq("_id", new ObjectId(item.getId())), toDocument(item));
    }

    public void delete(String id) {
        inventory.deleteOne(eq("_id", new ObjectId(id)));
    }

    public void reduceStock(String productId, int quantity) {
        inventory.updateOne(eq("productId", productId), Updates.inc("quantityOnHand", -quantity));
    }

    public InventoryItem findByProductId(String productId) {
        Document doc = inventory.find(eq("productId", productId)).first();
        return doc == null ? null : fromDocument(doc);
    }

    public List<InventoryItem> findAll() {
        List<InventoryItem> list = new ArrayList<>();
        for (Document doc : inventory.find().sort(Sorts.ascending("productName"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    public List<InventoryItem> findLowStock() {
        List<InventoryItem> list = new ArrayList<>();
        for (Document doc : inventory.find(expr(new Document("$lte", List.of("$quantityOnHand", "$reorderLevel"))))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    private Document toDocument(InventoryItem item) {
        Document doc = new Document("productId", item.getProductId())
                .append("productName", item.getProductName())
                .append("quantityOnHand", item.getQuantityOnHand())
                .append("reorderLevel", item.getReorderLevel())
                .append("supplier", item.getSupplier())
                .append("lastStockInDate", item.getLastStockInDate() == null ? new Date() : item.getLastStockInDate());
        if (item.getId() != null && !item.getId().isBlank()) {
            doc.append("_id", new ObjectId(item.getId()));
        }
        return doc;
    }

    private InventoryItem fromDocument(Document doc) {
        return new InventoryItem(
                doc.getObjectId("_id").toHexString(),
                doc.getString("productId"),
                doc.getString("productName"),
                doc.getInteger("quantityOnHand", 0),
                doc.getInteger("reorderLevel", 0),
                doc.getString("supplier"),
                doc.getDate("lastStockInDate")
        );
    }
}
