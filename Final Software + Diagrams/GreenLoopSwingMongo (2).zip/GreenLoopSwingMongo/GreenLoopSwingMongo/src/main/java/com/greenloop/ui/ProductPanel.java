package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.Product;
import com.greenloop.repository.ProductRepository;
import com.greenloop.util.ValidationUtil;

public class ProductPanel extends JPanel {
    private final ProductRepository repository = new ProductRepository();
    private final JTextField codeField = Style.textField();
    private final JTextField nameField = Style.textField();
    private final JTextField categoryField = Style.textField();
    private final JTextField priceField = Style.textField();
    private final JTextField ecoRatingField = Style.textField();
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Code", "Name", "Category", "Price", "Eco Rating"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable table = new JTable(model);
    private String selectedId;

    public ProductPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("1. Manage Product Catalogue", "Add, update and remove packaging products with price and eco-rating.");

        JPanel card = Style.card();
        JPanel form = Style.formPanel();
        Style.addField(form, 0, "Code", codeField);
        Style.addField(form, 1, "Name", nameField);
        Style.addField(form, 2, "Category", categoryField);
        Style.addField(form, 3, "Unit Price", priceField);
        Style.addField(form, 4, "Eco Rating 1-5", ecoRatingField);
        card.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton addButton = Style.primaryButton("Add Product");
        JButton updateButton = Style.secondaryButton("Update Selected");
        JButton deleteButton = Style.dangerButton("Remove Selected");
        JButton clearButton = Style.secondaryButton("Clear");
        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        buttons.add(clearButton);
        card.add(buttons, BorderLayout.SOUTH);

        page.add(card, BorderLayout.WEST);
        page.add(Style.tableScroll(table), BorderLayout.CENTER);
        Style.hideColumn(table, 0);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);   // Code
        table.getColumnModel().getColumn(2).setPreferredWidth(180);  // Name
        table.getColumnModel().getColumn(3).setPreferredWidth(110);  // Category
        table.getColumnModel().getColumn(4).setPreferredWidth(80);   // Price
        table.getColumnModel().getColumn(5).setPreferredWidth(80);   // Eco Rating
        add(page, BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> fillSelectedRow());
        addButton.addActionListener(e -> addProduct());
        updateButton.addActionListener(e -> updateProduct());
        deleteButton.addActionListener(e -> deleteProduct());
        clearButton.addActionListener(e -> clearForm());
        loadProducts();
    }

    private Product readForm() {
        String code = ValidationUtil.require(codeField.getText(), "Code");
        String name = ValidationUtil.require(nameField.getText(), "Name");
        String category = ValidationUtil.require(categoryField.getText(), "Category");
        double price = ValidationUtil.parseDouble(priceField.getText(), "Unit price");
        int eco = ValidationUtil.parseInt(ecoRatingField.getText(), "Eco rating");
        if (price < 0) throw new IllegalArgumentException("Unit price cannot be negative.");
        if (eco < 1 || eco > 5) throw new IllegalArgumentException("Eco rating must be between 1 and 5.");
        return new Product(selectedId, code, name, category, price, eco);
    }

    private void addProduct() {
        try {
            selectedId = null;
            repository.insert(readForm());
            loadProducts();
            clearForm();
            JOptionPane.showMessageDialog(this, "Product added successfully.");
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void updateProduct() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select a product first.");
            return;
        }
        try {
            repository.update(readForm());
            loadProducts();
            clearForm();
            JOptionPane.showMessageDialog(this, "Product updated successfully.");
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteProduct() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select a product first.");
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Remove selected product?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            repository.delete(selectedId);
            loadProducts();
            clearForm();
        }
    }

    private void loadProducts() {
        model.setRowCount(0);
        List<Product> products = repository.findAll();
        for (Product p : products) {
            model.addRow(new Object[]{p.getId(), p.getCode(), p.getName(), p.getCategory(), p.getUnitPrice(), p.getEcoRating()});
        }
    }

    private void fillSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        selectedId = String.valueOf(model.getValueAt(row, 0));
        codeField.setText(String.valueOf(model.getValueAt(row, 1)));
        nameField.setText(String.valueOf(model.getValueAt(row, 2)));
        categoryField.setText(String.valueOf(model.getValueAt(row, 3)));
        priceField.setText(String.valueOf(model.getValueAt(row, 4)));
        ecoRatingField.setText(String.valueOf(model.getValueAt(row, 5)));
    }

    private void clearForm() {
        selectedId = null;
        table.clearSelection();
        codeField.setText("");
        nameField.setText("");
        categoryField.setText("");
        priceField.setText("");
        ecoRatingField.setText("");
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}