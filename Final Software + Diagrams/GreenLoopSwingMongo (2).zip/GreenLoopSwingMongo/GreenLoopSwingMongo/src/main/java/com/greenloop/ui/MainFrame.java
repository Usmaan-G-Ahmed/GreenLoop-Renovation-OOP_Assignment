package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import com.greenloop.config.DatabaseConnection;

/**
 * GreenLoop – Main Dashboard Window  (restyled — obsidian + electric-emerald)
 */
public class MainFrame extends JFrame {

    // ── reuse Style constants ──────────────────────────────────────────────
    private static final Color BG_DEEP     = Style.BACKGROUND;
    private static final Color BG_CARD     = Style.CARD;
    private static final Color BG_CARD_HOV = Style.CARD_HOVER;
    private static final Color ACCENT      = Style.GREEN;
    private static final Color ACCENT_MID  = Style.GREEN_MID;
    private static final Color ACCENT_DARK = Style.GREEN_DARK;
    private static final Color TEXT_HEAD   = Style.TEXT;
    private static final Color TEXT_BODY   = new Color(130, 160, 134);
    private static final Color TEXT_MUTED  = Style.TEXT_SECONDARY;
    private static final Color BORDER      = Style.BORDER;
    private static final Color BORDER_SUB  = Style.BORDER_SUBTLE;
    private static final Color BORDER_ACC  = Style.BORDER_ACCENT;
    private static final Color CHROME      = Style.CHROME;

    // ── module definitions ───────────────────────────────────────────────────
    private static final Object[][] MODULES = {
        {"01", "📦", "Product Catalogue",    "Add · Update · Remove packaging\nproducts with eco-rating",       "ProductPanel"},
        {"02", "🏪", "Client Management",    "Add · Update · Remove retail\nclients and contact details",       "ClientPanel"},
        {"03", "📊", "Stock & Inventory",    "Track quantity on hand, reorder\nlevels, stock-in from suppliers", "InventoryPanel"},
        {"04", "🚚", "Delivery Agents",      "Add · Update · Remove delivery\npersonnel and vehicle details",   "DeliveryAgentPanel"},
        {"05", "🛒", "Client Orders",        "Create orders, assign products,\ncalculate totals",               "OrderPanel"},
        {"06", "📍", "Assign Deliveries",    "Schedule and track delivery\nstatus per order",                   "DeliveryAssignmentPanel"},
        {"07", "📈", "Sales & Inv. Reports", "Low-stock alerts and monthly\nrevenue summaries",                 "ReportPanel"},
    };

    public MainFrame() {
        setTitle("GreenLoop · Management System");
        setSize(1340, 820);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        getContentPane().setBackground(BG_DEEP);

        setLayout(new BorderLayout());
        add(buildTopBar(),    BorderLayout.NORTH);
        add(buildDashboard(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                DatabaseConnection.close();
                dispose();
                System.exit(0);
            }
        });
    }

    // ── top bar ──────────────────────────────────────────────────────────────

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(BG_DEEP);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_SUB),
            new EmptyBorder(14, 28, 14, 28)));

        // left – logo + text
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        left.setOpaque(false);

        // circular logo
        JLabel icon = new JLabel("🌿") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(ACCENT_DARK);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(BORDER_ACC);
                g2.drawOval(0, 0, getWidth()-1, getHeight()-1);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));
        icon.setPreferredSize(new Dimension(46, 46));
        icon.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel textBlock = new JPanel();
        textBlock.setLayout(new BoxLayout(textBlock, BoxLayout.Y_AXIS));
        textBlock.setOpaque(false);

        JLabel lbName = new JLabel("GreenLoop");
        lbName.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbName.setForeground(TEXT_HEAD);

        JLabel lbSub = new JLabel("ECO PACKAGING  ·  SUPPLY MANAGEMENT SYSTEM");
        lbSub.setFont(new Font("Consolas", Font.PLAIN, 10));
        lbSub.setForeground(TEXT_MUTED);

        textBlock.add(lbName);
        textBlock.add(lbSub);

        left.add(icon);
        left.add(textBlock);

        // right – LIVE pill
        JLabel livePill = new JLabel("● LIVE") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(15, 46, 18));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.setColor(new Color(30, 92, 36));
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 20, 20));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        livePill.setFont(new Font("Consolas", Font.PLAIN, 11));
        livePill.setForeground(ACCENT);
        livePill.setBorder(new EmptyBorder(4, 14, 4, 14));
        livePill.setOpaque(false);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setOpaque(false);
        right.add(livePill);

        bar.add(left, BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    // ── dashboard grid ───────────────────────────────────────────────────────

    private JScrollPane buildDashboard() {
        JPanel grid = new JPanel(new GridLayout(0, 3, 16, 16));
        grid.setBackground(BG_DEEP);
        grid.setBorder(new EmptyBorder(28, 28, 28, 28));

        for (Object[] mod : MODULES) {
            grid.add(buildCard(
                (String) mod[0],
                (String) mod[1],
                (String) mod[2],
                (String) mod[3],
                (String) mod[4]
            ));
        }

        JScrollPane sp = new JScrollPane(grid);
        sp.setBorder(null);
        sp.getViewport().setBackground(BG_DEEP);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        return sp;
    }

    private JPanel buildCard(String num, String icon, String title,
                             String desc, String panelClass) {
        boolean enabled = panelClass != null;

        // Rounded-rect card
        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(BORDER);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 12, 12));
                g2.dispose();
            }
        };
        card.setBackground(BG_CARD);
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(20, 22, 18, 22));

        // ── top: icon badge + number pill ──
        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);

        // icon in a small rounded box
        JLabel lbIcon = new JLabel(icon) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(ACCENT_DARK);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                g2.setColor(BORDER_ACC);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 8, 8));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        lbIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        lbIcon.setForeground(enabled ? TEXT_HEAD : TEXT_MUTED);
        lbIcon.setPreferredSize(new Dimension(38, 38));
        lbIcon.setHorizontalAlignment(SwingConstants.CENTER);
        lbIcon.setOpaque(false);
        topRow.add(lbIcon, BorderLayout.WEST);

        // number pill
        JLabel lbNum = new JLabel(num) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(15, 40, 18));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 6, 6));
                g2.setColor(new Color(30, 74, 34));
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 6, 6));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        lbNum.setFont(new Font("Consolas", Font.PLAIN, 10));
        lbNum.setForeground(ACCENT);
        lbNum.setHorizontalAlignment(SwingConstants.CENTER);
        lbNum.setPreferredSize(new Dimension(34, 22));
        lbNum.setOpaque(false);

        JPanel topRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 8));
        topRight.setOpaque(false);
        topRight.add(lbNum);
        topRow.add(topRight, BorderLayout.EAST);

        card.add(topRow, BorderLayout.NORTH);

        // ── centre: title + description ──
        JPanel centre = new JPanel();
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));
        centre.setOpaque(false);
        centre.setBorder(new EmptyBorder(14, 0, 10, 0));

        JLabel lbTitle = new JLabel(title);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbTitle.setForeground(enabled ? TEXT_HEAD : TEXT_MUTED);
        centre.add(lbTitle);
        centre.add(Box.createVerticalStrut(7));

        for (String line : desc.split("\n")) {
            JLabel lbLine = new JLabel(line);
            lbLine.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            lbLine.setForeground(TEXT_BODY);
            centre.add(lbLine);
        }

        card.add(centre, BorderLayout.CENTER);

        // ── bottom: separator + Open / Coming soon ──
        JPanel bottom = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(BORDER_SUB);
                g2.drawLine(0, 0, getWidth(), 0);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(12, 0, 0, 0));

        JLabel lbOpen = new JLabel(enabled ? "Open  →" : "coming soon");
        lbOpen.setFont(new Font("Consolas", Font.PLAIN, 11));
        lbOpen.setForeground(enabled ? ACCENT_MID : new Color(58, 92, 62));

        JPanel bottomRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottomRight.setOpaque(false);
        bottomRight.add(lbOpen);
        bottom.add(bottomRight, BorderLayout.EAST);
        card.add(bottom, BorderLayout.SOUTH);

        // ── hover + click ──
        if (enabled) {
            card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            card.addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) {
                    card.setBackground(BG_CARD_HOV);
                    lbOpen.setForeground(ACCENT);
                    card.repaint();
                }
                @Override public void mouseExited(MouseEvent e) {
                    card.setBackground(BG_CARD);
                    lbOpen.setForeground(ACCENT_MID);
                    card.repaint();
                }
                @Override public void mouseClicked(MouseEvent e) {
                    openPanel(panelClass, title);
                }
            });
        }

        return card;
    }

    // ── status bar ───────────────────────────────────────────────────────────

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(CHROME);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_SUB),
            new EmptyBorder(6, 28, 6, 28)));

        Font monoSm = new Font("Consolas", Font.PLAIN, 10);
        Color muted  = new Color(58, 92, 62);

        JLabel left = new JLabel("GreenLoop Management System  ·  v1.0");
        left.setFont(monoSm);
        left.setForeground(muted);

        JLabel right = new JLabel("Sustainable Packaging  ·  Sri Lanka  🌿");
        right.setFont(monoSm);
        right.setForeground(muted);

        bar.add(left,  BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    // ── panel navigation ─────────────────────────────────────────────────────

    private void openPanel(String className, String title) {
        try {
            Class<?> cls = Class.forName("com.greenloop.ui." + className);
            JPanel panel = (JPanel) cls.getDeclaredConstructor().newInstance();

            JDialog dlg = new JDialog(this, title, true);
            dlg.setSize(1100, 720);
            dlg.setLocationRelativeTo(this);
            dlg.getContentPane().setBackground(Style.BACKGROUND);
            dlg.getContentPane().add(panel);
            dlg.setVisible(true);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Panel not available yet:\n" + className,
                "Coming Soon", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // ── entry point ──────────────────────────────────────────────────────────

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}