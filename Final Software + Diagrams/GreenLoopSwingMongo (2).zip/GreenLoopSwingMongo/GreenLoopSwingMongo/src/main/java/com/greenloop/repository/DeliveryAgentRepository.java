package com.greenloop.repository;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.model.DeliveryAgent;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;

public class DeliveryAgentRepository {
    private final MongoCollection<Document> agents = DatabaseConnection.getDatabase().getCollection("delivery_agents");

    public String insert(DeliveryAgent agent) {
        Document doc = toDocument(agent);
        agents.insertOne(doc);
        return doc.getObjectId("_id").toHexString();
    }

    public void update(DeliveryAgent agent) {
        agents.replaceOne(eq("_id", new ObjectId(agent.getId())), toDocument(agent));
    }

    public void delete(String id) {
        agents.deleteOne(eq("_id", new ObjectId(id)));
    }

    public DeliveryAgent findById(String id) {
        Document doc = agents.find(eq("_id", new ObjectId(id))).first();
        return doc == null ? null : fromDocument(doc);
    }

    public List<DeliveryAgent> findAll() {
        List<DeliveryAgent> list = new ArrayList<>();
        for (Document doc : agents.find().sort(Sorts.ascending("name"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    private Document toDocument(DeliveryAgent a) {
        Document doc = new Document("name", a.getName())
                .append("email", a.getEmail())
                .append("phone", a.getPhone())
                .append("vehicleNumber", a.getVehicleNumber())
                .append("vehicleType", a.getVehicleType());
        if (a.getId() != null && !a.getId().isBlank()) {
            doc.append("_id", new ObjectId(a.getId()));
        }
        return doc;
    }

    private DeliveryAgent fromDocument(Document doc) {
        return new DeliveryAgent(
                doc.getObjectId("_id").toHexString(),
                doc.getString("name"),
                doc.getString("email"),
                doc.getString("phone"),
                doc.getString("vehicleNumber"),
                doc.getString("vehicleType")
        );
    }
}
