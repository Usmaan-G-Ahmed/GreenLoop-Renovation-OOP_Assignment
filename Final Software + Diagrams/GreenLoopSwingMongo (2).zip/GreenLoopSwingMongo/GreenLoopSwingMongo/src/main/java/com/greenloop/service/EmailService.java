package com.greenloop.service;

import com.greenloop.model.EmailLog;
import com.greenloop.repository.EmailLogRepository;
import com.greenloop.util.DateUtil;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import java.util.Properties;

/**
 * Sends real emails only when SMTP environment variables are configured.
 * If SMTP is not configured, the email is saved to MongoDB as DEMO_LOGGED.
 */
public class EmailService {
    private final EmailLogRepository emailLogRepository = new EmailLogRepository();

    public boolean sendClientDispatchEmail(String clientEmail, String clientName, String orderId) {
        String subject = "GreenLoop Order Dispatched";
        String body = "Dear " + clientName + ",\n\n"
                + "Your GreenLoop order " + shortOrderId(orderId) + " has been dispatched. "
                + "Thank you for choosing eco-friendly packaging.\n\n"
                + "Regards,\nGreenLoop Team";
        return send("CLIENT", clientEmail, subject, body);
    }

    public boolean sendDeliveryAssignmentEmail(String agentEmail, String agentName, String orderId, String deliveryDate) {
        String subject = "New GreenLoop Delivery Assigned";
        String body = "Dear " + agentName + ",\n\n"
                + "A new delivery has been assigned to you.\n"
                + "Order: " + shortOrderId(orderId) + "\n"
                + "Delivery date: " + deliveryDate + "\n\n"
                + "Please check the GreenLoop desktop system for the order details.\n\n"
                + "Regards,\nGreenLoop Operations";
        return send("DELIVERY_AGENT", agentEmail, subject, body);
    }

    public boolean send(String recipientType, String recipientEmail, String subject, String body) {
        if (!isSmtpConfigured()) {
            emailLogRepository.insert(new EmailLog(null, recipientType, recipientEmail, subject, body, "DEMO_LOGGED", DateUtil.nowAsDate()));
            return false;
        }

        try {
            sendUsingSmtp(recipientEmail, subject, body);
            emailLogRepository.insert(new EmailLog(null, recipientType, recipientEmail, subject, body, "SENT", DateUtil.nowAsDate()));
            return true;
        } catch (Exception ex) {
            emailLogRepository.insert(new EmailLog(null, recipientType, recipientEmail, subject, body, "FAILED: " + ex.getMessage(), DateUtil.nowAsDate()));
            return false;
        }
    }

    private void sendUsingSmtp(String to, String subject, String body) throws MessagingException {
        String host = System.getenv("GREENLOOP_SMTP_HOST");
        String port = System.getenv("GREENLOOP_SMTP_PORT");
        String username = System.getenv("GREENLOOP_SMTP_USERNAME");
        String password = System.getenv("GREENLOOP_SMTP_PASSWORD");
        String from = System.getenv().getOrDefault("GREENLOOP_FROM_EMAIL", username);

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port == null || port.isBlank() ? "587" : port);

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject);
        message.setText(body);
        Transport.send(message);
    }

    private boolean isSmtpConfigured() {
        return present("GREENLOOP_SMTP_HOST")
                && present("GREENLOOP_SMTP_USERNAME")
                && present("GREENLOOP_SMTP_PASSWORD");
    }

    private boolean present(String envName) {
        String value = System.getenv(envName);
        return value != null && !value.isBlank();
    }

    private String shortOrderId(String orderId) {
        if (orderId == null || orderId.length() < 6) return String.valueOf(orderId);
        return orderId.substring(0, 6).toUpperCase();
    }
}
