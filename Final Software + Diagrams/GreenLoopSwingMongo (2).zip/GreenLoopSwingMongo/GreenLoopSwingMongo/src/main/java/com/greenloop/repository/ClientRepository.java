package com.greenloop.repository;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.model.Client;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;

public class ClientRepository {
    private final MongoCollection<Document> clients = DatabaseConnection.getDatabase().getCollection("clients");

    public String insert(Client client) {
        Document doc = toDocument(client);
        clients.insertOne(doc);
        return doc.getObjectId("_id").toHexString();
    }

    public void update(Client client) {
        clients.replaceOne(eq("_id", new ObjectId(client.getId())), toDocument(client));
    }

    public void delete(String id) {
        clients.deleteOne(eq("_id", new ObjectId(id)));
    }

    public Client findById(String id) {
        Document doc = clients.find(eq("_id", new ObjectId(id))).first();
        return doc == null ? null : fromDocument(doc);
    }

    public List<Client> findAll() {
        List<Client> list = new ArrayList<>();
        for (Document doc : clients.find().sort(Sorts.ascending("name"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    private Document toDocument(Client c) {
        Document doc = new Document("name", c.getName())
                .append("email", c.getEmail())
                .append("phone", c.getPhone())
                .append("address", c.getAddress());
        if (c.getId() != null && !c.getId().isBlank()) {
            doc.append("_id", new ObjectId(c.getId()));
        }
        return doc;
    }

    private Client fromDocument(Document doc) {
        return new Client(
                doc.getObjectId("_id").toHexString(),
                doc.getString("name"),
                doc.getString("email"),
                doc.getString("phone"),
                doc.getString("address")
        );
    }
}
