package com.greenloop.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

/**
 * Single MongoDB connection class used by all repositories.
 * Default URL: mongodb://localhost:27017
 * You can override it with environment variable GREENLOOP_MONGO_URI.
 */
public final class DatabaseConnection {
    private static final String DEFAULT_URI = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "greenloop_db";

    private static MongoClient mongoClient;
    private static MongoDatabase database;

    private DatabaseConnection() {
    }

    public static synchronized MongoDatabase getDatabase() {
        if (database == null) {
            String uri = System.getenv().getOrDefault("GREENLOOP_MONGO_URI", DEFAULT_URI);
            mongoClient = MongoClients.create(uri);
            database = mongoClient.getDatabase(DATABASE_NAME);
        }
        return database;
    }

    public static boolean testConnection() {
        try {
            getDatabase().runCommand(new org.bson.Document("ping", 1));
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public static synchronized void close() {
        if (mongoClient != null) {
            mongoClient.close();
            mongoClient = null;
            database = null;
        }
    }
}
