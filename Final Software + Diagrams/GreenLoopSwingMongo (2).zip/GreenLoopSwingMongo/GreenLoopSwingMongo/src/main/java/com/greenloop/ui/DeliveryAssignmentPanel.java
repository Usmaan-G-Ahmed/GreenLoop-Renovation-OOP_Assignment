package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.Client;
import com.greenloop.model.DeliveryAgent;
import com.greenloop.model.Order;
import com.greenloop.repository.ClientRepository;
import com.greenloop.repository.DeliveryAgentRepository;
import com.greenloop.repository.OrderRepository;
import com.greenloop.service.EmailService;
import com.greenloop.util.DateUtil;

public class DeliveryAssignmentPanel extends JPanel {
    private final OrderRepository orderRepository = new OrderRepository();
    private final DeliveryAgentRepository agentRepository = new DeliveryAgentRepository();
    private final ClientRepository clientRepository = new ClientRepository();
    private final EmailService emailService = new EmailService();

    private final JComboBox<DeliveryAgent> agentCombo = new JComboBox<>();
    private final JTextField deliveryDateField = Style.textField();
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"Order ID", "Client", "Total", "Status", "Assigned Agent", "Delivery Date"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);

    public DeliveryAssignmentPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("6, 8, 9. Delivery Assignment & Email Notifications", "Assign delivery agents, track delivery status and notify clients/agents by email.");

        JPanel card = Style.card();
        JPanel form = Style.formPanel();
        deliveryDateField.setText(java.time.LocalDate.now().plusDays(1).toString());
        Style.addField(form, 0, "Delivery Agent", agentCombo);
        Style.addField(form, 1, "Delivery Date yyyy-MM-dd", deliveryDateField);
        card.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton assignButton = Style.primaryButton("Assign Agent + Email Agent");
        JButton dispatchButton = Style.secondaryButton("Mark Dispatched + Email Client");
        JButton deliveredButton = Style.secondaryButton("Mark Delivered");
        JButton refreshButton = Style.secondaryButton("Refresh");
        buttons.add(assignButton);
        buttons.add(dispatchButton);
        buttons.add(deliveredButton);
        buttons.add(refreshButton);
        card.add(buttons, BorderLayout.SOUTH);

        page.add(card, BorderLayout.WEST);
        page.add(Style.tableScroll(table), BorderLayout.CENTER);
        Style.hideColumn(table, 0);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);  // Client
        table.getColumnModel().getColumn(2).setPreferredWidth(90);   // Total
        table.getColumnModel().getColumn(3).setPreferredWidth(100);  // Status
        table.getColumnModel().getColumn(4).setPreferredWidth(150);  // Agent
        table.getColumnModel().getColumn(5).setPreferredWidth(110);  // Delivery Date
        add(page, BorderLayout.CENTER);

        assignButton.addActionListener(e -> assignAgent());
        dispatchButton.addActionListener(e -> markDispatched());
        deliveredButton.addActionListener(e -> updateStatus("DELIVERED", false));
        refreshButton.addActionListener(e -> refreshAll());
        refreshAll();
        Style.styleComboBox(agentCombo);
    }

    private void refreshAll() {
        loadAgents();
        loadOrders();
    }

    private void loadAgents() {
        agentCombo.removeAllItems();
        for (DeliveryAgent agent : agentRepository.findAll()) {
            agentCombo.addItem(agent);
        }
    }

    private void loadOrders() {
        model.setRowCount(0);
        for (Order order : orderRepository.findOpenOrders()) {
            model.addRow(new Object[]{
                    order.getId(),
                    order.getClientName(),
                    order.getTotalAmount(),
                    order.getStatus(),
                    order.getAssignedAgentName() == null ? "-" : order.getAssignedAgentName(),
                    DateUtil.formatDate(order.getDeliveryDate())
            });
        }
    }

    private void assignAgent() {
        try {
            String orderId = selectedOrderId();
            DeliveryAgent agent = (DeliveryAgent) agentCombo.getSelectedItem();
            if (agent == null) throw new IllegalArgumentException("Please add/select a delivery agent first.");
            Date deliveryDate = DateUtil.parseDateOrToday(deliveryDateField.getText());
            orderRepository.assignAgent(orderId, agent.getId(), agent.getName(), deliveryDate);
            boolean sent = emailService.sendDeliveryAssignmentEmail(agent.getEmail(), agent.getName(), orderId, DateUtil.formatDate(deliveryDate));
            loadOrders();
            JOptionPane.showMessageDialog(this, sent ? "Agent assigned and email sent." : "Agent assigned. Email saved in demo log because SMTP is not configured.");
        } catch (Exception ex) { showError(ex); }
    }

    private void markDispatched() {
        try {
            String orderId = selectedOrderId();
            Order order = orderRepository.findById(orderId);
            if (order == null) throw new IllegalArgumentException("Order not found.");
            Client client = clientRepository.findById(order.getClientId());
            if (client == null) throw new IllegalArgumentException("Client not found for this order.");
            orderRepository.updateStatus(orderId, "DISPATCHED");
            boolean sent = emailService.sendClientDispatchEmail(client.getEmail(), client.getName(), orderId);
            loadOrders();
            JOptionPane.showMessageDialog(this, sent ? "Order dispatched and client email sent." : "Order dispatched. Email saved in demo log because SMTP is not configured.");
        } catch (Exception ex) { showError(ex); }
    }

    private void updateStatus(String status, boolean showEmailMessage) {
        try {
            String orderId = selectedOrderId();
            orderRepository.updateStatus(orderId, status);
            loadOrders();
            JOptionPane.showMessageDialog(this, "Order status changed to " + status + ".");
        } catch (Exception ex) { showError(ex); }
    }

    private String selectedOrderId() {
        int row = table.getSelectedRow();
        if (row < 0) throw new IllegalArgumentException("Please select an order first.");
        return String.valueOf(model.getValueAt(row, 0));
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}