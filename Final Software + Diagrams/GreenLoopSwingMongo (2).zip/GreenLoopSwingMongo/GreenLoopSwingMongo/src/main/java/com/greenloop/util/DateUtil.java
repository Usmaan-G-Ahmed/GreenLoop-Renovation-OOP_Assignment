package com.greenloop.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

public final class DateUtil {
    private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DISPLAY_DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private DateUtil() {
    }

    public static Date nowAsDate() {
        return Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date toDate(LocalDateTime dateTime) {
        return Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date parseDateOrToday(String value) {
        if (value == null || value.isBlank()) {
            return Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
        }
        try {
            LocalDate date = LocalDate.parse(value.trim(), DISPLAY_DATE);
            return Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        } catch (DateTimeParseException ex) {
            return Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
        }
    }

    public static String formatDate(Date date) {
        if (date == null) return "";
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().format(DISPLAY_DATE);
    }

    public static String formatDateTime(Date date) {
        if (date == null) return "";
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().format(DISPLAY_DATE_TIME);
    }
}
