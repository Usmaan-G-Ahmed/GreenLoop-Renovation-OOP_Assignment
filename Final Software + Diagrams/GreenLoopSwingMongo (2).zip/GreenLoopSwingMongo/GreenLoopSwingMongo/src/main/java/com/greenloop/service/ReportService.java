package com.greenloop.service;

import com.greenloop.model.InventoryItem;
import com.greenloop.model.Order;
import com.greenloop.repository.InventoryRepository;
import com.greenloop.repository.OrderRepository;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public class ReportService {
    private final InventoryRepository inventoryRepository = new InventoryRepository();
    private final OrderRepository orderRepository = new OrderRepository();

    public List<InventoryItem> getLowStockItems() {
        return inventoryRepository.findLowStock();
    }

    public List<Order> getOrdersForMonth(int year, int month) {
        LocalDate firstDay = LocalDate.of(year, month, 1);
        LocalDate nextMonth = firstDay.plusMonths(1);
        Date start = Date.from(firstDay.atStartOfDay(ZoneId.systemDefault()).toInstant());
        Date end = Date.from(nextMonth.atStartOfDay(ZoneId.systemDefault()).toInstant());
        return orderRepository.findOrdersByCreatedDate(start, end);
    }

    public double calculateMonthlyRevenue(int year, int month) {
        return getOrdersForMonth(year, month).stream()
                .mapToDouble(Order::getTotalAmount)
                .sum();
    }
}
