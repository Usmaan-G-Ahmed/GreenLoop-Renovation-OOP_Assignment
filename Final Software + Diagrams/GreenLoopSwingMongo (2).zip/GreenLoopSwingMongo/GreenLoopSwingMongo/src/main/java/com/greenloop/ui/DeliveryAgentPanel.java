package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.DeliveryAgent;
import com.greenloop.repository.DeliveryAgentRepository;
import com.greenloop.util.ValidationUtil;

public class DeliveryAgentPanel extends JPanel {
    private final DeliveryAgentRepository repository = new DeliveryAgentRepository();
    private final JTextField nameField = Style.textField();
    private final JTextField emailField = Style.textField();
    private final JTextField phoneField = Style.textField();
    private final JTextField vehicleNumberField = Style.textField();
    private final JTextField vehicleTypeField = Style.textField();
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Email", "Phone", "Vehicle No", "Vehicle Type"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private String selectedId;

    public DeliveryAgentPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("4. Manage Delivery Agents", "Add, update and remove delivery personnel and vehicle details.");

        JPanel card = Style.card();
        JPanel form = Style.formPanel();
        Style.addField(form, 0, "Agent Name", nameField);
        Style.addField(form, 1, "Email", emailField);
        Style.addField(form, 2, "Phone", phoneField);
        Style.addField(form, 3, "Vehicle Number", vehicleNumberField);
        Style.addField(form, 4, "Vehicle Type", vehicleTypeField);
        card.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton addButton = Style.primaryButton("Add Agent");
        JButton updateButton = Style.secondaryButton("Update Selected");
        JButton deleteButton = Style.dangerButton("Remove Selected");
        JButton clearButton = Style.secondaryButton("Clear");
        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        buttons.add(clearButton);
        card.add(buttons, BorderLayout.SOUTH);

        page.add(card, BorderLayout.WEST);
        page.add(Style.tableScroll(table), BorderLayout.CENTER);
        Style.hideColumn(table, 0);
        table.getColumnModel().getColumn(1).setPreferredWidth(140);  // Name
        table.getColumnModel().getColumn(2).setPreferredWidth(190);  // Email
        table.getColumnModel().getColumn(3).setPreferredWidth(100);  // Phone
        table.getColumnModel().getColumn(4).setPreferredWidth(110);  // Vehicle No
        table.getColumnModel().getColumn(5).setPreferredWidth(110);  // Vehicle Type
        add(page, BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> fillSelectedRow());
        addButton.addActionListener(e -> addAgent());
        updateButton.addActionListener(e -> updateAgent());
        deleteButton.addActionListener(e -> deleteAgent());
        clearButton.addActionListener(e -> clearForm());
        loadAgents();
    }

    private DeliveryAgent readForm() {
        String name = ValidationUtil.require(nameField.getText(), "Agent name");
        String email = ValidationUtil.require(emailField.getText(), "Email");
        String phone = ValidationUtil.require(phoneField.getText(), "Phone");
        String vehicleNumber = ValidationUtil.require(vehicleNumberField.getText(), "Vehicle number");
        String vehicleType = ValidationUtil.require(vehicleTypeField.getText(), "Vehicle type");
        if (!email.contains("@")) throw new IllegalArgumentException("Email must be valid.");
        return new DeliveryAgent(selectedId, name, email, phone, vehicleNumber, vehicleType);
    }

    private void addAgent() {
        try {
            selectedId = null;
            repository.insert(readForm());
            loadAgents();
            clearForm();
            JOptionPane.showMessageDialog(this, "Delivery agent added.");
        } catch (Exception ex) { showError(ex); }
    }

    private void updateAgent() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select an agent first.");
            return;
        }
        try {
            repository.update(readForm());
            loadAgents();
            clearForm();
            JOptionPane.showMessageDialog(this, "Delivery agent updated.");
        } catch (Exception ex) { showError(ex); }
    }

    private void deleteAgent() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select an agent first.");
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Remove selected agent?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            repository.delete(selectedId);
            loadAgents();
            clearForm();
        }
    }

    private void loadAgents() {
        model.setRowCount(0);
        for (DeliveryAgent a : repository.findAll()) {
            model.addRow(new Object[]{a.getId(), a.getName(), a.getEmail(), a.getPhone(), a.getVehicleNumber(), a.getVehicleType()});
        }
    }

    private void fillSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        selectedId = String.valueOf(model.getValueAt(row, 0));
        nameField.setText(String.valueOf(model.getValueAt(row, 1)));
        emailField.setText(String.valueOf(model.getValueAt(row, 2)));
        phoneField.setText(String.valueOf(model.getValueAt(row, 3)));
        vehicleNumberField.setText(String.valueOf(model.getValueAt(row, 4)));
        vehicleTypeField.setText(String.valueOf(model.getValueAt(row, 5)));
    }

    private void clearForm() {
        selectedId = null;
        table.clearSelection();
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        vehicleNumberField.setText("");
        vehicleTypeField.setText("");
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}