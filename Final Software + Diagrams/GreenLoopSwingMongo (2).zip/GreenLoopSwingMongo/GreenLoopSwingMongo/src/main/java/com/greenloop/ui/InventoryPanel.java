package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.InventoryItem;
import com.greenloop.model.Product;
import com.greenloop.repository.InventoryRepository;
import com.greenloop.repository.ProductRepository;
import com.greenloop.util.DateUtil;
import com.greenloop.util.ValidationUtil;

public class InventoryPanel extends JPanel {
    private final ProductRepository productRepository = new ProductRepository();
    private final InventoryRepository inventoryRepository = new InventoryRepository();
    private final JComboBox<Product> productCombo = new JComboBox<>();
    private final JTextField quantityField = Style.textField();
    private final JTextField reorderField = Style.textField();
    private final JTextField supplierField = Style.textField();
    private final JTextField stockInField = Style.textField();
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Product ID", "Product", "Qty", "Reorder Level", "Supplier", "Last Stock-In"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private String selectedId;

    public InventoryPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("3. Manage Stock / Inventory", "Track quantity on hand, reorder levels and supplier stock-in details.");

        JPanel card = Style.card();
        JPanel form = Style.formPanel();
        Style.addField(form, 0, "Product", productCombo);
        Style.addField(form, 1, "Quantity On Hand", quantityField);
        Style.addField(form, 2, "Reorder Level", reorderField);
        Style.addField(form, 3, "Supplier", supplierField);
        stockInField.setText("0");
        Style.addField(form, 4, "Stock-In Add Qty", stockInField);
        card.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton addButton = Style.primaryButton("Add Inventory");
        JButton updateButton = Style.secondaryButton("Update Selected");
        JButton stockInButton = Style.secondaryButton("Stock-In");
        JButton deleteButton = Style.dangerButton("Remove Selected");
        JButton refreshButton = Style.secondaryButton("Refresh Products");
        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(stockInButton);
        buttons.add(deleteButton);
        buttons.add(refreshButton);
        card.add(buttons, BorderLayout.SOUTH);

        page.add(card, BorderLayout.WEST);
        page.add(Style.tableScroll(table), BorderLayout.CENTER);
        Style.hideColumn(table, 0);
        Style.hideColumn(table, 1);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);  // Product
        table.getColumnModel().getColumn(3).setPreferredWidth(70);   // Qty
        table.getColumnModel().getColumn(4).setPreferredWidth(100);  // Reorder Level
        table.getColumnModel().getColumn(5).setPreferredWidth(150);  // Supplier
        table.getColumnModel().getColumn(6).setPreferredWidth(110);  // Last Stock-In
        add(page, BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> fillSelectedRow());
        addButton.addActionListener(e -> addInventory());
        updateButton.addActionListener(e -> updateInventory());
        stockInButton.addActionListener(e -> stockIn());
        deleteButton.addActionListener(e -> deleteInventory());
        refreshButton.addActionListener(e -> refreshAll());
        refreshAll();
        Style.styleComboBox(productCombo);
    }

    private void refreshAll() {
        loadProducts();
        loadInventory();
    }

    private void loadProducts() {
        productCombo.removeAllItems();
        for (Product p : productRepository.findAll()) {
            productCombo.addItem(p);
        }
    }

    private InventoryItem readForm() {
        Product selectedProduct = (Product) productCombo.getSelectedItem();
        if (selectedProduct == null) throw new IllegalArgumentException("Please add/select a product first.");
        int qty = ValidationUtil.parseInt(quantityField.getText(), "Quantity on hand");
        int reorder = ValidationUtil.parseInt(reorderField.getText(), "Reorder level");
        String supplier = ValidationUtil.require(supplierField.getText(), "Supplier");
        if (qty < 0 || reorder < 0) throw new IllegalArgumentException("Quantity and reorder level cannot be negative.");
        Date lastStockIn = selectedId == null ? DateUtil.nowAsDate() : DateUtil.parseDateOrToday(String.valueOf(table.getSelectedRow() >= 0 ? model.getValueAt(table.getSelectedRow(), 6) : ""));
        return new InventoryItem(selectedId, selectedProduct.getId(), selectedProduct.getName(), qty, reorder, supplier, lastStockIn);
    }

    private void addInventory() {
        try {
            selectedId = null;
            inventoryRepository.insert(readForm());
            loadInventory();
            clearForm();
            JOptionPane.showMessageDialog(this, "Inventory record added.");
        } catch (Exception ex) { showError(ex); }
    }

    private void updateInventory() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select an inventory record first.");
            return;
        }
        try {
            inventoryRepository.update(readForm());
            loadInventory();
            clearForm();
            JOptionPane.showMessageDialog(this, "Inventory record updated.");
        } catch (Exception ex) { showError(ex); }
    }

    private void stockIn() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Select an inventory record before stock-in.");
            return;
        }
        try {
            int addQty = ValidationUtil.parseInt(stockInField.getText(), "Stock-in quantity");
            int currentQty = ValidationUtil.parseInt(quantityField.getText(), "Quantity on hand");
            if (addQty <= 0) throw new IllegalArgumentException("Stock-in quantity must be more than 0.");
            quantityField.setText(String.valueOf(currentQty + addQty));
            InventoryItem item = readForm();
            item.setLastStockInDate(DateUtil.nowAsDate());
            inventoryRepository.update(item);
            loadInventory();
            clearForm();
            JOptionPane.showMessageDialog(this, "Stock-in completed.");
        } catch (Exception ex) { showError(ex); }
    }

    private void deleteInventory() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select an inventory record first.");
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Remove selected inventory record?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            inventoryRepository.delete(selectedId);
            loadInventory();
            clearForm();
        }
    }

    private void loadInventory() {
        model.setRowCount(0);
        for (InventoryItem item : inventoryRepository.findAll()) {
            model.addRow(new Object[]{item.getId(), item.getProductId(), item.getProductName(), item.getQuantityOnHand(), item.getReorderLevel(), item.getSupplier(), DateUtil.formatDate(item.getLastStockInDate())});
        }
    }

    private void fillSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        selectedId = String.valueOf(model.getValueAt(row, 0));
        String productId = String.valueOf(model.getValueAt(row, 1));
        selectProduct(productId);
        quantityField.setText(String.valueOf(model.getValueAt(row, 3)));
        reorderField.setText(String.valueOf(model.getValueAt(row, 4)));
        supplierField.setText(String.valueOf(model.getValueAt(row, 5)));
        stockInField.setText("0");
    }

    private void selectProduct(String productId) {
        for (int i = 0; i < productCombo.getItemCount(); i++) {
            Product p = productCombo.getItemAt(i);
            if (p.getId().equals(productId)) {
                productCombo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void clearForm() {
        selectedId = null;
        table.clearSelection();
        quantityField.setText("");
        reorderField.setText("");
        supplierField.setText("");
        stockInField.setText("0");
        if (productCombo.getItemCount() > 0) productCombo.setSelectedIndex(0);
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}