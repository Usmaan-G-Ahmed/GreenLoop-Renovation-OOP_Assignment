package com.greenloop.repository;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.model.EmailLog;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EmailLogRepository {
    private final MongoCollection<Document> emailLogs = DatabaseConnection.getDatabase().getCollection("email_logs");

    public String insert(EmailLog log) {
        Document doc = new Document("recipientType", log.getRecipientType())
                .append("recipientEmail", log.getRecipientEmail())
                .append("subject", log.getSubject())
                .append("body", log.getBody())
                .append("status", log.getStatus())
                .append("createdAt", log.getCreatedAt() == null ? new Date() : log.getCreatedAt());
        emailLogs.insertOne(doc);
        return doc.getObjectId("_id").toHexString();
    }

    public List<EmailLog> findAll() {
        List<EmailLog> list = new ArrayList<>();
        for (Document doc : emailLogs.find().sort(Sorts.descending("createdAt"))) {
            list.add(new EmailLog(
                    doc.getObjectId("_id").toHexString(),
                    doc.getString("recipientType"),
                    doc.getString("recipientEmail"),
                    doc.getString("subject"),
                    doc.getString("body"),
                    doc.getString("status"),
                    doc.getDate("createdAt")
            ));
        }
        return list;
    }
}
