package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.EmailLog;
import com.greenloop.model.InventoryItem;
import com.greenloop.model.Order;
import com.greenloop.repository.EmailLogRepository;
import com.greenloop.service.ReportService;
import com.greenloop.util.DateUtil;
import com.greenloop.util.MoneyUtil;
import com.greenloop.util.ValidationUtil;

public class ReportPanel extends JPanel {
    private final ReportService reportService = new ReportService();
    private final EmailLogRepository emailLogRepository = new EmailLogRepository();
    private final JTextField yearField = Style.textField();
    private final JTextField monthField = Style.textField();
    private final JLabel summaryLabel = new JLabel("Revenue: $0.00 | Orders: 0 | Low-stock items: 0");

    private final DefaultTableModel salesModel = new DefaultTableModel(new String[]{"Order ID", "Client", "Total", "Status", "Agent", "Created"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable salesTable = new JTable(salesModel);

    private final DefaultTableModel lowStockModel = new DefaultTableModel(new String[]{"Inventory ID", "Product", "Qty", "Reorder Level", "Supplier"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable lowStockTable = new JTable(lowStockModel);

    private final DefaultTableModel emailModel = new DefaultTableModel(new String[]{"Recipient Type", "Email", "Subject", "Status", "Created"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable emailTable = new JTable(emailModel);

    public ReportPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("7. Monthly Sales & Inventory Reports", "Generate revenue summaries, low-stock alerts and email notification logs.");

        JPanel topCard = Style.card();
        JPanel form = Style.formPanel();
        LocalDate now = LocalDate.now();
        yearField.setText(String.valueOf(now.getYear()));
        monthField.setText(String.valueOf(now.getMonthValue()));
        summaryLabel.setFont(Style.BOLD_FONT);
        Style.addField(form, 0, "Year", yearField);
        Style.addField(form, 1, "Month 1-12", monthField);
        Style.addField(form, 2, "Summary", summaryLabel);
        topCard.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton generateButton = Style.primaryButton("Generate Report");
        JButton exportButton = Style.secondaryButton("Export Sales CSV");
        JButton refreshEmailsButton = Style.secondaryButton("Refresh Email Logs");
        buttons.add(generateButton);
        buttons.add(exportButton);
        buttons.add(refreshEmailsButton);
        topCard.add(buttons, BorderLayout.SOUTH);
        page.add(topCard, BorderLayout.NORTH);

        JTabbedPane tabs = Style.tabbedPane();
        tabs.addTab("Monthly Sales", Style.tableScroll(salesTable));
        tabs.addTab("Low Stock Alerts", Style.tableScroll(lowStockTable));
        tabs.addTab("Email Logs", Style.tableScroll(emailTable));
        page.add(tabs, BorderLayout.CENTER);

        // Sales table columns: OrderID(0) Client(1) Total(2) Status(3) Agent(4) Created(5)
        Style.hideColumn(salesTable, 0);
        salesTable.getColumnModel().getColumn(1).setPreferredWidth(160);
        salesTable.getColumnModel().getColumn(2).setPreferredWidth(90);
        salesTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        salesTable.getColumnModel().getColumn(4).setPreferredWidth(140);
        salesTable.getColumnModel().getColumn(5).setPreferredWidth(150);

        // Low stock table columns: ID(0) Product(1) Qty(2) ReorderLevel(3) Supplier(4)
        Style.hideColumn(lowStockTable, 0);
        lowStockTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        lowStockTable.getColumnModel().getColumn(2).setPreferredWidth(70);
        lowStockTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        lowStockTable.getColumnModel().getColumn(4).setPreferredWidth(180);

        // Email log columns: RecipientType(0) Email(1) Subject(2) Status(3) Created(4)
        emailTable.getColumnModel().getColumn(0).setPreferredWidth(110);
        emailTable.getColumnModel().getColumn(1).setPreferredWidth(180);
        emailTable.getColumnModel().getColumn(2).setPreferredWidth(240);
        emailTable.getColumnModel().getColumn(3).setPreferredWidth(80);
        emailTable.getColumnModel().getColumn(4).setPreferredWidth(150);
        add(page, BorderLayout.CENTER);

        generateButton.addActionListener(e -> generateReport());
        exportButton.addActionListener(e -> exportSalesCsv());
        refreshEmailsButton.addActionListener(e -> loadEmailLogs());
        generateReport();
        loadEmailLogs();
    }

    private void generateReport() {
        try {
            int year = ValidationUtil.parseInt(yearField.getText(), "Year");
            int month = ValidationUtil.parseInt(monthField.getText(), "Month");
            if (month < 1 || month > 12) throw new IllegalArgumentException("Month must be between 1 and 12.");

            List<Order> orders = reportService.getOrdersForMonth(year, month);
            List<InventoryItem> lowStock = reportService.getLowStockItems();
            double revenue = reportService.calculateMonthlyRevenue(year, month);

            salesModel.setRowCount(0);
            for (Order order : orders) {
                salesModel.addRow(new Object[]{
                        order.getId(),
                        order.getClientName(),
                        order.getTotalAmount(),
                        order.getStatus(),
                        order.getAssignedAgentName() == null ? "-" : order.getAssignedAgentName(),
                        DateUtil.formatDateTime(order.getCreatedAt())
                });
            }

            lowStockModel.setRowCount(0);
            for (InventoryItem item : lowStock) {
                lowStockModel.addRow(new Object[]{item.getId(), item.getProductName(), item.getQuantityOnHand(), item.getReorderLevel(), item.getSupplier()});
            }

            summaryLabel.setText("Revenue: " + MoneyUtil.format(revenue) + " | Orders: " + orders.size() + " | Low-stock items: " + lowStock.size());
        } catch (Exception ex) { showError(ex); }
    }

    private void loadEmailLogs() {
        emailModel.setRowCount(0);
        for (EmailLog log : emailLogRepository.findAll()) {
            emailModel.addRow(new Object[]{log.getRecipientType(), log.getRecipientEmail(), log.getSubject(), log.getStatus(), DateUtil.formatDateTime(log.getCreatedAt())});
        }
    }

    private void exportSalesCsv() {
        try {
            String fileName = "greenloop_sales_report_" + yearField.getText().trim() + "_" + monthField.getText().trim() + ".csv";
            try (FileWriter writer = new FileWriter(fileName)) {
                writer.write("Order ID,Client,Total,Status,Agent,Created\n");
                for (int r = 0; r < salesModel.getRowCount(); r++) {
                    for (int c = 0; c < salesModel.getColumnCount(); c++) {
                        writer.write(String.valueOf(salesModel.getValueAt(r, c)).replace(",", " "));
                        if (c < salesModel.getColumnCount() - 1) writer.write(",");
                    }
                    writer.write("\n");
                }
            }
            JOptionPane.showMessageDialog(this, "CSV exported to project folder: " + fileName);
        } catch (IOException ex) {
            showError(ex);
        }
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}