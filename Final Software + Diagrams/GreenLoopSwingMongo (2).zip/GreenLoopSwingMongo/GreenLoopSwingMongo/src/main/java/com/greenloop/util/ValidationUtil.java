package com.greenloop.util;

public final class ValidationUtil {
    private ValidationUtil() {
    }

    public static String require(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }
        return value.trim();
    }

    public static double parseDouble(String value, String fieldName) {
        try {
            return Double.parseDouble(require(value, fieldName));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }

    public static int parseInt(String value, String fieldName) {
        try {
            return Integer.parseInt(require(value, fieldName));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(fieldName + " must be a valid whole number.");
        }
    }

    public static String optional(String value) {
        return value == null ? "" : value.trim();
    }
}
