package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.Client;
import com.greenloop.model.InventoryItem;
import com.greenloop.model.Order;
import com.greenloop.model.OrderItem;
import com.greenloop.model.Product;
import com.greenloop.repository.ClientRepository;
import com.greenloop.repository.InventoryRepository;
import com.greenloop.repository.OrderRepository;
import com.greenloop.repository.ProductRepository;
import com.greenloop.util.DateUtil;
import com.greenloop.util.MoneyUtil;
import com.greenloop.util.ValidationUtil;

public class OrderPanel extends JPanel {
    private final ClientRepository clientRepository = new ClientRepository();
    private final ProductRepository productRepository = new ProductRepository();
    private final InventoryRepository inventoryRepository = new InventoryRepository();
    private final OrderRepository orderRepository = new OrderRepository();

    private final JComboBox<Client> clientCombo = new JComboBox<>();
    private final JComboBox<Product> productCombo = new JComboBox<>();
    private final JTextField quantityField = Style.textField();
    private final JLabel totalLabel = new JLabel("Total: $0.00");

    private final List<OrderItem> currentItems = new ArrayList<>();
    private final DefaultTableModel itemModel = new DefaultTableModel(new String[]{"Product ID", "Product", "Qty", "Unit Price", "Line Total"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable itemTable = new JTable(itemModel);

    private final DefaultTableModel orderModel = new DefaultTableModel(new String[]{"Order ID", "Client", "Total", "Status", "Agent", "Created"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable orderTable = new JTable(orderModel);

    public OrderPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("5. Process Client Orders", "Create orders, assign products and calculate totals. Stock is reduced when the order is created.");

        JPanel card = Style.card();
        JPanel form = Style.formPanel();
        Style.addField(form, 0, "Client", clientCombo);
        Style.addField(form, 1, "Product", productCombo);
        Style.addField(form, 2, "Quantity", quantityField);
        totalLabel.setFont(Style.TITLE_FONT);
        Style.addField(form, 3, "Order Total", totalLabel);
        card.add(form, BorderLayout.NORTH);

        JPanel itemCard = Style.card();
        itemCard.add(Style.tableScroll(itemTable), BorderLayout.CENTER);
        card.add(itemCard, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton addItemButton = Style.primaryButton("Add Item");
        JButton removeItemButton = Style.secondaryButton("Remove Item");
        JButton createOrderButton = Style.primaryButton("Create Order");
        JButton clearButton = Style.secondaryButton("Clear Order");
        JButton refreshButton = Style.secondaryButton("Refresh Lists");
        buttons.add(addItemButton);
        buttons.add(removeItemButton);
        buttons.add(createOrderButton);
        buttons.add(clearButton);
        buttons.add(refreshButton);
        card.add(buttons, BorderLayout.SOUTH);

        page.add(card, BorderLayout.WEST);
        page.add(Style.tableScroll(orderTable), BorderLayout.CENTER);
        Style.hideColumn(orderTable, 0);
        orderTable.getColumnModel().getColumn(1).setPreferredWidth(160);  // Client
        orderTable.getColumnModel().getColumn(2).setPreferredWidth(90);   // Total
        orderTable.getColumnModel().getColumn(3).setPreferredWidth(100);  // Status
        orderTable.getColumnModel().getColumn(4).setPreferredWidth(140);  // Agent
        orderTable.getColumnModel().getColumn(5).setPreferredWidth(140);  // Created
        add(page, BorderLayout.CENTER);

        addItemButton.addActionListener(e -> addItem());
        removeItemButton.addActionListener(e -> removeSelectedItem());
        createOrderButton.addActionListener(e -> createOrder());
        clearButton.addActionListener(e -> clearCurrentOrder());
        refreshButton.addActionListener(e -> refreshAll());
        refreshAll();
        Style.styleComboBox(clientCombo);
        Style.styleComboBox(productCombo);
    }

    private void refreshAll() {
        loadClients();
        loadProducts();
        loadOrders();
    }

    private void loadClients() {
        clientCombo.removeAllItems();
        for (Client c : clientRepository.findAll()) {
            clientCombo.addItem(c);
        }
    }

    private void loadProducts() {
        productCombo.removeAllItems();
        for (Product p : productRepository.findAll()) {
            productCombo.addItem(p);
        }
    }

    private void addItem() {
        try {
            Product product = (Product) productCombo.getSelectedItem();
            if (product == null) throw new IllegalArgumentException("Please add/select a product first.");
            int qty = ValidationUtil.parseInt(quantityField.getText(), "Quantity");
            if (qty <= 0) throw new IllegalArgumentException("Quantity must be more than 0.");
            currentItems.add(new OrderItem(product.getId(), product.getName(), qty, product.getUnitPrice()));
            refreshItemTable();
            quantityField.setText("");
        } catch (Exception ex) { showError(ex); }
    }

    private void removeSelectedItem() {
        int row = itemTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an item to remove.");
            return;
        }
        currentItems.remove(row);
        refreshItemTable();
    }

    private void createOrder() {
        try {
            Client client = (Client) clientCombo.getSelectedItem();
            if (client == null) throw new IllegalArgumentException("Please add/select a client first.");
            if (currentItems.isEmpty()) throw new IllegalArgumentException("Please add at least one order item.");
            validateStockBeforeSaving();

            Order order = new Order();
            order.setClientId(client.getId());
            order.setClientName(client.getName());
            order.setItems(new ArrayList<>(currentItems));
            order.setTotalAmount(calculateTotal());
            order.setStatus("CREATED");
            order.setCreatedAt(DateUtil.nowAsDate());
            String orderId = orderRepository.insert(order);

            for (OrderItem item : currentItems) {
                inventoryRepository.reduceStock(item.getProductId(), item.getQuantity());
            }

            clearCurrentOrder();
            loadOrders();
            JOptionPane.showMessageDialog(this, "Order created successfully. Order ID: " + orderId.substring(0, 6).toUpperCase());
        } catch (Exception ex) { showError(ex); }
    }

    private void validateStockBeforeSaving() {
        for (OrderItem item : currentItems) {
            InventoryItem inventory = inventoryRepository.findByProductId(item.getProductId());
            if (inventory == null) {
                throw new IllegalArgumentException("No inventory record found for " + item.getProductName() + ".");
            }
            if (inventory.getQuantityOnHand() < item.getQuantity()) {
                throw new IllegalArgumentException("Not enough stock for " + item.getProductName() + ". Available: " + inventory.getQuantityOnHand());
            }
        }
    }

    private void refreshItemTable() {
        itemModel.setRowCount(0);
        for (OrderItem item : currentItems) {
            itemModel.addRow(new Object[]{item.getProductId(), item.getProductName(), item.getQuantity(), item.getUnitPrice(), item.getLineTotal()});
        }
        totalLabel.setText("Total: " + MoneyUtil.format(calculateTotal()));
    }

    private double calculateTotal() {
        return currentItems.stream().mapToDouble(OrderItem::getLineTotal).sum();
    }

    private void loadOrders() {
        orderModel.setRowCount(0);
        for (Order order : orderRepository.findAll()) {
            orderModel.addRow(new Object[]{
                    order.getId(),
                    order.getClientName(),
                    order.getTotalAmount(),
                    order.getStatus(),
                    order.getAssignedAgentName() == null ? "-" : order.getAssignedAgentName(),
                    DateUtil.formatDateTime(order.getCreatedAt())
            });
        }
    }

    private void clearCurrentOrder() {
        currentItems.clear();
        itemModel.setRowCount(0);
        totalLabel.setText("Total: $0.00");
        quantityField.setText("");
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}