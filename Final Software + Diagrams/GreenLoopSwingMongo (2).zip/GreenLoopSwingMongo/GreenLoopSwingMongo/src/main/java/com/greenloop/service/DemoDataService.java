package com.greenloop.service;

import com.greenloop.model.Client;
import com.greenloop.model.DeliveryAgent;
import com.greenloop.model.InventoryItem;
import com.greenloop.model.Product;
import com.greenloop.repository.ClientRepository;
import com.greenloop.repository.DeliveryAgentRepository;
import com.greenloop.repository.InventoryRepository;
import com.greenloop.repository.ProductRepository;
import com.greenloop.util.DateUtil;

public class DemoDataService {
    private final ProductRepository productRepository = new ProductRepository();
    private final ClientRepository clientRepository = new ClientRepository();
    private final InventoryRepository inventoryRepository = new InventoryRepository();
    private final DeliveryAgentRepository agentRepository = new DeliveryAgentRepository();

    public void insertSampleDataIfEmpty() {
        if (productRepository.findAll().isEmpty()) {
            String p1 = productRepository.insert(new Product(null, "BIO-WRAP-01", "Biodegradable Wrap", "Wrapping", 850.00, 5));
            String p2 = productRepository.insert(new Product(null, "REC-BOX-02", "Recycled Box Medium", "Boxes", 120.00, 4));
            String p3 = productRepository.insert(new Product(null, "COM-BAG-03", "Compostable Bag", "Bags", 35.00, 5));
            inventoryRepository.insert(new InventoryItem(null, p1, "Biodegradable Wrap", 40, 20, "Eco Lanka Suppliers", DateUtil.nowAsDate()));
            inventoryRepository.insert(new InventoryItem(null, p2, "Recycled Box Medium", 200, 60, "Green Paper Mill", DateUtil.nowAsDate()));
            inventoryRepository.insert(new InventoryItem(null, p3, "Compostable Bag", 25, 30, "BioPack Imports", DateUtil.nowAsDate()));
        }

        if (clientRepository.findAll().isEmpty()) {
            clientRepository.insert(new Client(null, "Island Fresh Retail", "client1@example.com", "0771234567", "Colombo"));
            clientRepository.insert(new Client(null, "Kandy Organic Store", "client2@example.com", "0779876543", "Kandy"));
        }

        if (agentRepository.findAll().isEmpty()) {
            agentRepository.insert(new DeliveryAgent(null, "Nimal Perera", "agent1@example.com", "0711111111", "WP-CAB-1234", "Van"));
            agentRepository.insert(new DeliveryAgent(null, "Kamal Silva", "agent2@example.com", "0722222222", "CP-BIKE-5566", "Motorbike"));
        }
    }
}
