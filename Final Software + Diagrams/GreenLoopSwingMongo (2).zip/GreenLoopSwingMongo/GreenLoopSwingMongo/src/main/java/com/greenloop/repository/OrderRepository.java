package com.greenloop.repository;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.model.Order;
import com.greenloop.model.OrderItem;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.mongodb.client.model.Filters.*;

public class OrderRepository {
    private final MongoCollection<Document> orders = DatabaseConnection.getDatabase().getCollection("orders");

    public String insert(Order order) {
        Document doc = toDocument(order);
        orders.insertOne(doc);
        return doc.getObjectId("_id").toHexString();
    }

    public void update(Order order) {
        orders.replaceOne(eq("_id", new ObjectId(order.getId())), toDocument(order));
    }

    public void delete(String id) {
        orders.deleteOne(eq("_id", new ObjectId(id)));
    }

    public Order findById(String id) {
        Document doc = orders.find(eq("_id", new ObjectId(id))).first();
        return doc == null ? null : fromDocument(doc);
    }

    public List<Order> findAll() {
        List<Order> list = new ArrayList<>();
        for (Document doc : orders.find().sort(Sorts.descending("createdAt"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    public List<Order> findOpenOrders() {
        List<Order> list = new ArrayList<>();
        for (Document doc : orders.find(ne("status", "DELIVERED")).sort(Sorts.descending("createdAt"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    public List<Order> findOrdersByCreatedDate(Date startInclusive, Date endExclusive) {
        List<Order> list = new ArrayList<>();
        for (Document doc : orders.find(and(gte("createdAt", startInclusive), lt("createdAt", endExclusive))).sort(Sorts.descending("createdAt"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    public void assignAgent(String orderId, String agentId, String agentName, Date deliveryDate) {
        orders.updateOne(eq("_id", new ObjectId(orderId)), Updates.combine(
                Updates.set("assignedAgentId", agentId),
                Updates.set("assignedAgentName", agentName),
                Updates.set("deliveryDate", deliveryDate),
                Updates.set("status", "ASSIGNED")
        ));
    }

    public void updateStatus(String orderId, String status) {
        orders.updateOne(eq("_id", new ObjectId(orderId)), Updates.set("status", status));
    }

    private Document toDocument(Order o) {
        List<Document> itemDocs = new ArrayList<>();
        for (OrderItem item : o.getItems()) {
            itemDocs.add(new Document("productId", item.getProductId())
                    .append("productName", item.getProductName())
                    .append("quantity", item.getQuantity())
                    .append("unitPrice", item.getUnitPrice())
                    .append("lineTotal", item.getLineTotal()));
        }

        Document doc = new Document("clientId", o.getClientId())
                .append("clientName", o.getClientName())
                .append("items", itemDocs)
                .append("totalAmount", o.getTotalAmount())
                .append("status", o.getStatus())
                .append("assignedAgentId", o.getAssignedAgentId())
                .append("assignedAgentName", o.getAssignedAgentName())
                .append("deliveryDate", o.getDeliveryDate())
                .append("createdAt", o.getCreatedAt() == null ? new Date() : o.getCreatedAt());
        if (o.getId() != null && !o.getId().isBlank()) {
            doc.append("_id", new ObjectId(o.getId()));
        }
        return doc;
    }

    private Order fromDocument(Document doc) {
        Order order = new Order();
        order.setId(doc.getObjectId("_id").toHexString());
        order.setClientId(doc.getString("clientId"));
        order.setClientName(doc.getString("clientName"));
        order.setTotalAmount(getDouble(doc, "totalAmount"));
        order.setStatus(doc.getString("status"));
        order.setAssignedAgentId(doc.getString("assignedAgentId"));
        order.setAssignedAgentName(doc.getString("assignedAgentName"));
        order.setDeliveryDate(doc.getDate("deliveryDate"));
        order.setCreatedAt(doc.getDate("createdAt"));

        List<OrderItem> items = new ArrayList<>();
        List<Document> itemDocs = doc.getList("items", Document.class, new ArrayList<>());
        for (Document itemDoc : itemDocs) {
            items.add(new OrderItem(
                    itemDoc.getString("productId"),
                    itemDoc.getString("productName"),
                    itemDoc.getInteger("quantity", 0),
                    getDouble(itemDoc, "unitPrice")
            ));
        }
        order.setItems(items);
        return order;
    }

    private double getDouble(Document doc, String field) {
        Number number = doc.get(field, Number.class);
        return number == null ? 0.0 : number.doubleValue();
    }
}
