package com.greenloop.model;

public class Product {
    private String id;
    private String code;
    private String name;
    private String category;
    private double unitPrice;
    private int ecoRating;

    public Product() {
    }

    public Product(String id, String code, String name, String category, double unitPrice, int ecoRating) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.category = category;
        this.unitPrice = unitPrice;
        this.ecoRating = ecoRating;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }
    public int getEcoRating() { return ecoRating; }
    public void setEcoRating(int ecoRating) { this.ecoRating = ecoRating; }

    @Override
    public String toString() {
        return name + " (" + code + ")";
    }
}
