package com.greenloop.model;

import java.util.Date;

public class EmailLog {
    private String id;
    private String recipientType;
    private String recipientEmail;
    private String subject;
    private String body;
    private String status;
    private Date createdAt;

    public EmailLog() {
    }

    public EmailLog(String id, String recipientType, String recipientEmail, String subject, String body, String status, Date createdAt) {
        this.id = id;
        this.recipientType = recipientType;
        this.recipientEmail = recipientEmail;
        this.subject = subject;
        this.body = body;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getRecipientType() { return recipientType; }
    public void setRecipientType(String recipientType) { this.recipientType = recipientType; }
    public String getRecipientEmail() { return recipientEmail; }
    public void setRecipientEmail(String recipientEmail) { this.recipientEmail = recipientEmail; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
}
