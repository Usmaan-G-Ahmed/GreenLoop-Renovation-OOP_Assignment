package com.greenloop.model;

import java.util.Date;

public class InventoryItem {
    private String id;
    private String productId;
    private String productName;
    private int quantityOnHand;
    private int reorderLevel;
    private String supplier;
    private Date lastStockInDate;

    public InventoryItem() {
    }

    public InventoryItem(String id, String productId, String productName, int quantityOnHand, int reorderLevel, String supplier, Date lastStockInDate) {
        this.id = id;
        this.productId = productId;
        this.productName = productName;
        this.quantityOnHand = quantityOnHand;
        this.reorderLevel = reorderLevel;
        this.supplier = supplier;
        this.lastStockInDate = lastStockInDate;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public int getQuantityOnHand() { return quantityOnHand; }
    public void setQuantityOnHand(int quantityOnHand) { this.quantityOnHand = quantityOnHand; }
    public int getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }
    public String getSupplier() { return supplier; }
    public void setSupplier(String supplier) { this.supplier = supplier; }
    public Date getLastStockInDate() { return lastStockInDate; }
    public void setLastStockInDate(Date lastStockInDate) { this.lastStockInDate = lastStockInDate; }
}
