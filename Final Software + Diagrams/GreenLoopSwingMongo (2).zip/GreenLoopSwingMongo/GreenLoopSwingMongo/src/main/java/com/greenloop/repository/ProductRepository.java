package com.greenloop.repository;

import com.greenloop.config.DatabaseConnection;
import com.greenloop.model.Product;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;

public class ProductRepository {
    private final MongoCollection<Document> products = DatabaseConnection.getDatabase().getCollection("products");

    public String insert(Product product) {
        Document doc = toDocument(product);
        products.insertOne(doc);
        return doc.getObjectId("_id").toHexString();
    }

    public void update(Product product) {
        products.replaceOne(eq("_id", new ObjectId(product.getId())), toDocument(product));
    }

    public void delete(String id) {
        products.deleteOne(eq("_id", new ObjectId(id)));
    }

    public Product findById(String id) {
        Document doc = products.find(eq("_id", new ObjectId(id))).first();
        return doc == null ? null : fromDocument(doc);
    }

    public Product findByCode(String code) {
        Document doc = products.find(eq("code", code)).first();
        return doc == null ? null : fromDocument(doc);
    }

    public List<Product> findAll() {
        List<Product> list = new ArrayList<>();
        for (Document doc : products.find().sort(Sorts.ascending("name"))) {
            list.add(fromDocument(doc));
        }
        return list;
    }

    private Document toDocument(Product p) {
        Document doc = new Document("code", p.getCode())
                .append("name", p.getName())
                .append("category", p.getCategory())
                .append("unitPrice", p.getUnitPrice())
                .append("ecoRating", p.getEcoRating());
        if (p.getId() != null && !p.getId().isBlank()) {
            doc.append("_id", new ObjectId(p.getId()));
        }
        return doc;
    }

    private Product fromDocument(Document doc) {
        return new Product(
                doc.getObjectId("_id").toHexString(),
                doc.getString("code"),
                doc.getString("name"),
                doc.getString("category"),
                getDouble(doc, "unitPrice"),
                doc.getInteger("ecoRating", 0)
        );
    }

    private double getDouble(Document doc, String field) {
        Number number = doc.get(field, Number.class);
        return number == null ? 0.0 : number.doubleValue();
    }
}
