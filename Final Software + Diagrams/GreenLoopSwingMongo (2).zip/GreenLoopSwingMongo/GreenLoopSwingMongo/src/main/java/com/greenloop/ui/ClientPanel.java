package com.greenloop.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.greenloop.model.Client;
import com.greenloop.repository.ClientRepository;
import com.greenloop.util.ValidationUtil;

public class ClientPanel extends JPanel {
    private final ClientRepository repository = new ClientRepository();
    private final JTextField nameField = Style.textField();
    private final JTextField emailField = Style.textField();
    private final JTextField phoneField = Style.textField();
    private final JTextField addressField = Style.textField();
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Email", "Phone", "Address"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private String selectedId;

    public ClientPanel() {
        setLayout(new BorderLayout());
        JPanel page = Style.page("2. Manage Clients", "Maintain retail business clients and their contact details.");

        JPanel card = Style.card();
        JPanel form = Style.formPanel();
        Style.addField(form, 0, "Client Name", nameField);
        Style.addField(form, 1, "Email", emailField);
        Style.addField(form, 2, "Phone", phoneField);
        Style.addField(form, 3, "Address", addressField);
        card.add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBackground(Style.CARD);
        JButton addButton = Style.primaryButton("Add Client");
        JButton updateButton = Style.secondaryButton("Update Selected");
        JButton deleteButton = Style.dangerButton("Remove Selected");
        JButton clearButton = Style.secondaryButton("Clear");
        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        buttons.add(clearButton);
        card.add(buttons, BorderLayout.SOUTH);

        page.add(card, BorderLayout.WEST);
        page.add(Style.tableScroll(table), BorderLayout.CENTER);
        Style.hideColumn(table, 0);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);  // Name
        table.getColumnModel().getColumn(2).setPreferredWidth(200);  // Email
        table.getColumnModel().getColumn(3).setPreferredWidth(110);  // Phone
        table.getColumnModel().getColumn(4).setPreferredWidth(200);  // Address
        add(page, BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> fillSelectedRow());
        addButton.addActionListener(e -> addClient());
        updateButton.addActionListener(e -> updateClient());
        deleteButton.addActionListener(e -> deleteClient());
        clearButton.addActionListener(e -> clearForm());
        loadClients();
    }

    private Client readForm() {
        String name = ValidationUtil.require(nameField.getText(), "Client name");
        String email = ValidationUtil.require(emailField.getText(), "Email");
        String phone = ValidationUtil.require(phoneField.getText(), "Phone");
        String address = ValidationUtil.require(addressField.getText(), "Address");
        if (!email.contains("@")) throw new IllegalArgumentException("Email must be valid.");
        return new Client(selectedId, name, email, phone, address);
    }

    private void addClient() {
        try {
            selectedId = null;
            repository.insert(readForm());
            loadClients();
            clearForm();
            JOptionPane.showMessageDialog(this, "Client added successfully.");
        } catch (Exception ex) { showError(ex); }
    }

    private void updateClient() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select a client first.");
            return;
        }
        try {
            repository.update(readForm());
            loadClients();
            clearForm();
            JOptionPane.showMessageDialog(this, "Client updated successfully.");
        } catch (Exception ex) { showError(ex); }
    }

    private void deleteClient() {
        if (selectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select a client first.");
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Remove selected client?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            repository.delete(selectedId);
            loadClients();
            clearForm();
        }
    }

    private void loadClients() {
        model.setRowCount(0);
        for (Client c : repository.findAll()) {
            model.addRow(new Object[]{c.getId(), c.getName(), c.getEmail(), c.getPhone(), c.getAddress()});
        }
    }

    private void fillSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        selectedId = String.valueOf(model.getValueAt(row, 0));
        nameField.setText(String.valueOf(model.getValueAt(row, 1)));
        emailField.setText(String.valueOf(model.getValueAt(row, 2)));
        phoneField.setText(String.valueOf(model.getValueAt(row, 3)));
        addressField.setText(String.valueOf(model.getValueAt(row, 4)));
    }

    private void clearForm() {
        selectedId = null;
        table.clearSelection();
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        addressField.setText("");
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}