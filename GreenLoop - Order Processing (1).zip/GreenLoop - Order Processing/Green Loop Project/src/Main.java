import javax.swing.*;

import ui.OrderPanel;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Order Processing - GreenLoop");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(700, 500);
            frame.add(new OrderPanel());
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        }); 
    } 
}