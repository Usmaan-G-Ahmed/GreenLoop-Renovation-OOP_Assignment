package ui;
import models.Order;
import models.OrderItem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
 
public class OrderPanel extends JPanel{

    private JTextField clientNameField;
    private JTextField productNameField;
    private JTextField priceField;  
    private JTextField quantityField;
    private JLabel totalLabel;
    private DefaultTableModel tableModel;
    private Order currentOrder;
    private int orderIdCounter = 1;
    private JPanel topPanel;
    private JPanel midPanel;
    private JPanel bottomPanel;

    public OrderPanel(){ 
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(createTopPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);
    }

    //Top-Client name + New Order Button
    private JPanel createTopPanel(){
        topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Client Name:"));
        clientNameField = new JTextField(15);
        topPanel.add(clientNameField);

        JButton newOrderBtn = new JButton("New Order");
        newOrderBtn.addActionListener(e -> createNewOrder(newOrderBtn));
        topPanel.add(newOrderBtn);

        return topPanel;

    }

    // MIDDLE — Product input + Table
    private JPanel createTablePanel(){
        midPanel = new JPanel(new BorderLayout(5, 5));

        //input row
        JPanel inputRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputRow.add(new JLabel("Product: "));
        productNameField = new JTextField(10);
        inputRow.add(productNameField);

        inputRow.add(new JLabel("Price: "));
        priceField = new JTextField(6);
        inputRow.add(priceField);

        inputRow.add(new JLabel("Qty: "));
        quantityField = new JTextField(4);
        inputRow.add(quantityField);

        JButton addItemBtn = new JButton("Add Item");
        addItemBtn.addActionListener(e -> addItemToOrder());
        inputRow.add(addItemBtn);

        // delete button
        JButton deleteItemBtn = new JButton("Delete Item");
        deleteItemBtn.addActionListener(e -> deleteItemFromOrder());
        inputRow.add(deleteItemBtn);

        midPanel.add(inputRow, BorderLayout.NORTH);

        //table
        tableModel = new DefaultTableModel(
            new String[]{"Product", "Price(Rs. )","Quantity", "Subtotal (Rs.)" },0
        );
        JTable table = new JTable(tableModel);
        midPanel.add(new JScrollPane(table), BorderLayout.CENTER);

        return midPanel;
    }

    //bottom - total + place orderbtn
    private JPanel createBottomPanel() {
        bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalLabel = new JLabel("Total: Rs. 0.00");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        bottomPanel.add(totalLabel);

        JButton placeOrderBtn = new JButton("Place Order");
        placeOrderBtn.addActionListener(e -> placeOrder());
        bottomPanel.add(placeOrderBtn);

        return bottomPanel;
    }

    //actions
    private void createNewOrder(JButton orderButton){
        String clientName = clientNameField.getText().trim();
        if(clientName.isEmpty()){
            JOptionPane.showMessageDialog(this, "Please enter client name!");
            return;
        }
        currentOrder = new Order(orderIdCounter++, clientName);
        tableModel.setRowCount(0);
        totalLabel.setText("Total: Rs. 0.00");
        JOptionPane.showMessageDialog(this, "Order Created For: " +clientName);

        topPanel.remove(orderButton);

        JButton deleteOrderBtn = new JButton("Delete Order");
        deleteOrderBtn.addActionListener(e -> deleteOrder(deleteOrderBtn));
        topPanel.add(deleteOrderBtn);
    }

    private void addItemToOrder(){
        if(currentOrder == null){
            JOptionPane.showMessageDialog(this, "Please Enter an order first!");
            return;
        }
        try{
            String productName = productNameField.getText().trim();
            double price = Double.parseDouble(priceField.getText().trim());
            int quantity = Integer.parseInt(quantityField.getText().trim());

            OrderItem item = new OrderItem(productName, price, quantity);
            currentOrder.addItem(item);

            tableModel.addRow(new Object[]{
                productName,
                String.format("%.2f", price),
                quantity,
                String.format("%.2f", item.getSubtotal())
            });

            totalLabel.setText("Total: Rs. " + String.format("%.2f", currentOrder.calculateTotal()));

            productNameField.setText("");
            priceField.setText("");
            quantityField.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid price and quantity!");
        }
    }

    private void placeOrder() {
        if (currentOrder == null || currentOrder.getItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No items in the order!");
            return;
        }
        JOptionPane.showMessageDialog(this,
            "Order #" + currentOrder.getOrderId() +
            " placed for " + currentOrder.getClientName() +
            "\nTotal: Rs. " + String.format("%.2f", currentOrder.calculateTotal())
        );
        currentOrder = null;
        clientNameField.setText("");
        tableModel.setRowCount(0);
        totalLabel.setText("Total: Rs. 0.00");
        
        JButton newOrderBtn = new JButton("New Order");
        newOrderBtn.addActionListener(e -> createNewOrder(newOrderBtn));
        topPanel.add(newOrderBtn);
    }
    
    private void deleteOrder(JButton deleteOrderBtn){
        JOptionPane.showMessageDialog(this, "Order For " +currentOrder.getClientName() +" Was Deleted");

        currentOrder = null;
        clientNameField.setText("");
        tableModel.setRowCount(0);
        totalLabel.setText("Total: Rs. 0.00");
        orderIdCounter--;

        topPanel.remove(deleteOrderBtn);

        JButton newOrderBtn = new JButton("New Order");
        newOrderBtn.addActionListener(e -> createNewOrder(newOrderBtn));
        topPanel.add(newOrderBtn);

        
    }

    private void deleteItemFromOrder() {
    // get the table showing on screen
    int selectedRow = ((JTable) ((JScrollPane) ((JPanel) getComponent(1))
        .getComponent(1)).getViewport().getView()).getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row to delete!");
        return;
    }

    // remove from table display
    tableModel.removeRow(selectedRow);

    // remove from order object
    currentOrder.getItems().remove(selectedRow);

    // recalculate total
    totalLabel.setText("Total: Rs. " + String.format("%.2f", currentOrder.calculateTotal()));
}
}
