package models; 

import java.util.ArrayList;
import java.util.List;

public class Order{
    private int orderId;
    private String clientName;
    private List<OrderItem> items;
    
    public Order(int orderId, String clientName){
        this.orderId = orderId;
        this.clientName = clientName;
        this.items = new ArrayList<>();
    }

    public void addItem(OrderItem item){
        items.add(item);
    }

    public double calculateTotal(){
        double total = 0;
        for(OrderItem item : items){
            total += item.getSubtotal();
        }
        return total;
    }

    public int getOrderId() {return orderId;}
    public String getClientName() {return clientName;}
    public List<OrderItem> getItems() {return items;}
}