package models; 

public class OrderItem{
    private String productName;
    private double price;
    private int quantity;

    public OrderItem(String prodctName, double price, int quantity){
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }

    public double getSubtotal(){
        return price * quantity;
    }

    public String getProductName() {return productName;}
    public double getPrice() {return price;}
    public int getQuantity() {return quantity;}
}