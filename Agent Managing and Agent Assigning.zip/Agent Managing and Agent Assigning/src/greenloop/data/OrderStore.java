package greenloop.data;

import greenloop.model.Order;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class OrderStore {

    // Singleton 
    private static OrderStore instance;

    public static OrderStore getInstance() {
        if (instance == null) instance = new OrderStore();
        return instance;
    }

    // MongoDB connection 
    private MongoCollection<Document> collection;
    private List<Order> orders = new ArrayList<>();
    private int nextId = 1;

    private OrderStore() {
        // Connect to same MongoDB database as AgentStore
        MongoClient client = new MongoClient("localhost", 27017);
        MongoDatabase db = client.getDatabase("greenloopDB");
        collection = db.getCollection("orders");

        // Load orders from MongoDB when app starts
        loadFromDB();
    }

    //  CRUD 

    public List<Order> getOrders() {
        return orders;
    }

    public void addOrder(Order o) {
        Order newOrder = new Order(nextId++, o.getClientName(),
                o.getProduct(), o.getQuantity(), o.getTotalAmount());
        orders.add(newOrder);

        // Save to MongoDB
        Document doc = new Document("orderId", newOrder.getOrderId())
                .append("clientName",     newOrder.getClientName())
                .append("product",        newOrder.getProduct())
                .append("quantity",       newOrder.getQuantity())
                .append("totalAmount",    newOrder.getTotalAmount())
                .append("deliveryStatus", newOrder.getDeliveryStatus())
                .append("assignedAgentId", newOrder.getAssignedAgentId());
        collection.insertOne(doc);
    }

    public void removeOrder(int id) {
        orders.removeIf(o -> o.getOrderId() == id);
        collection.deleteOne(new Document("orderId", id));
    }

    public void updateOrder(Order o) {
        collection.updateOne(
                new Document("orderId", o.getOrderId()),
                new Document("$set", new Document("deliveryStatus", o.getDeliveryStatus())
                        .append("assignedAgentId", o.getAssignedAgentId())));
    }

    public Order findById(int id) {
        return orders.stream()
                    .filter(o -> o.getOrderId() == id)
                    .findFirst()
                    .orElse(null);
    }

    //  Load from MongoDB 

    private void loadFromDB() {
        orders.clear();
        for (Document doc : collection.find()) {
            int id = doc.getInteger("orderId");
            Order o = new Order(id,
                    doc.getString("clientName"),
                    doc.getString("product"),
                    doc.getInteger("quantity"),
                    doc.getDouble("totalAmount"));
            o.setDeliveryStatus(doc.getString("deliveryStatus"));

            // assignedAgentId can be null
            Integer agentId = doc.getInteger("assignedAgentId");
            o.setAssignedAgentId(agentId);

            orders.add(o);
            if (id >= nextId) nextId = id + 1;
        }
    }
}
