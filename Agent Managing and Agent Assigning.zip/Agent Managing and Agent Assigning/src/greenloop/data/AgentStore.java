package greenloop.data;

import greenloop.model.DeliveryAgent;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class AgentStore {

    // Singleton
    private static AgentStore instance;

    public static AgentStore getInstance() {
        if (instance == null) instance = new AgentStore();
        return instance;
    }

    // MongoDB connection 
    private MongoCollection<Document> collection;
    private List<DeliveryAgent> agents = new ArrayList<>();
    private int nextId = 1;

    private AgentStore() {
        // Connect to MongoDB running locally
        MongoClient client = new MongoClient("localhost", 27017);
        MongoDatabase db = client.getDatabase("greenloopDB");
        collection = db.getCollection("agents");

        // Load agents from MongoDB when app starts
        loadFromDB();
    }

    // CRUD 

    public List<DeliveryAgent> getAgents() {
        return agents;
    }

    public void addAgent(DeliveryAgent a) {
        DeliveryAgent newAgent = new DeliveryAgent(
                nextId++, a.getName(), a.getPhone(), a.getEmail(),
                a.getVehicleType(), a.getVehiclePlate(), a.getStatus());
        agents.add(newAgent);

        // Save to MongoDB
        Document doc = new Document("id", newAgent.getId())
                .append("name",         newAgent.getName())
                .append("phone",        newAgent.getPhone())
                .append("email",        newAgent.getEmail())
                .append("vehicleType",  newAgent.getVehicleType())
                .append("vehiclePlate", newAgent.getVehiclePlate())
                .append("status",       newAgent.getStatus());
        collection.insertOne(doc);
    }

    public void removeAgent(int id) {
        agents.removeIf(a -> a.getId() == id);

        // Remove from MongoDB
        collection.deleteOne(new Document("id", id));
    }

    public void updateAgent(DeliveryAgent a) {
        // Update in MongoDB
        collection.updateOne(
                new Document("id", a.getId()),
                new Document("$set", new Document("name", a.getName())
                        .append("phone",        a.getPhone())
                        .append("email",        a.getEmail())
                        .append("vehicleType",  a.getVehicleType())
                        .append("vehiclePlate", a.getVehiclePlate())
                        .append("status",       a.getStatus())));
    }

    public DeliveryAgent findById(int id) {
        return agents.stream()
                    .filter(a -> a.getId() == id)
                    .findFirst()
                    .orElse(null);
    }

    // ── Load from MongoDB ────────────────────────────────────────

    private void loadFromDB() {
        agents.clear();
        for (Document doc : collection.find()) {
            int id = doc.getInteger("id");
            agents.add(new DeliveryAgent(
                    id,
                    doc.getString("name"),
                    doc.getString("phone"),
                    doc.getString("email"),
                    doc.getString("vehicleType"),
                    doc.getString("vehiclePlate"),
                    doc.getString("status")));
            if (id >= nextId) nextId = id + 1;
        }
    }
}