package greenloop.ui;

import java.awt.*;
import javax.swing.*;

public class MainApp extends JFrame {

    public MainApp() {
        setTitle("GreenLoop – Task 4: Manage Delivery Agents");
        setSize(950, 650);
        setMinimumSize(new Dimension(800, 500));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(new ManageAgentsPanel());
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}
