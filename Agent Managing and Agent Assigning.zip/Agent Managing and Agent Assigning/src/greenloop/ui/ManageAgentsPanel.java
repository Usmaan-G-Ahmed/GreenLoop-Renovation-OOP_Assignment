package greenloop.ui;

import greenloop.data.AgentStore;
import greenloop.model.DeliveryAgent;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class ManageAgentsPanel extends JPanel {

    private static final String[] VEHICLE_TYPES = {"Motorbike","Van","Three Wheeler","Truck","Car"};
    private static final String[] STATUSES = {"Available","On Delivery","Off Duty"};

    private static final Color GREEN_DARK  = new Color(34, 85, 34);
    private static final Color GREEN_LIGHT = new Color(230, 245, 230);
    private static final Color ACCENT      = new Color(56, 142, 60);

    private AgentStore agentStore = AgentStore.getInstance();

    private DefaultTableModel tableModel;
    private JTable agentTable;

    private JTextField txtName, txtPhone, txtEmail, txtVehiclePlate;
    private JComboBox<String> cmbVehicleType, cmbStatus;

    public ManageAgentsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(GREEN_LIGHT);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        add(buildHeader(),   BorderLayout.NORTH);
        add(buildTable(),    BorderLayout.CENTER);
        add(buildFormArea(), BorderLayout.SOUTH);

        refreshTable();
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(GREEN_DARK);
        p.setBorder(new EmptyBorder(12, 16, 12, 16));

        JLabel title = new JLabel("🚚  Manage Delivery Agents");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);

        p.add(title, BorderLayout.WEST);
        return p;
    }

    private JPanel buildTable() {
        String[] cols = {"ID","Name","Phone","Email","Vehicle Type","Plate No.","Status"};

        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        agentTable = new JTable(tableModel);
        agentTable.setRowHeight(26);
        agentTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        agentTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        agentTable.getTableHeader().setBackground(ACCENT);
        agentTable.getTableHeader().setForeground(Color.WHITE);
        agentTable.setSelectionBackground(new Color(178, 223, 178));
        agentTable.setGridColor(new Color(200, 220, 200));

        agentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) fillFormFromSelection();
        });

        JScrollPane scroll = new JScrollPane(agentTable);
        scroll.setBorder(BorderFactory.createTitledBorder("Delivery Agents"));

        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(GREEN_LIGHT);
        p.add(scroll, BorderLayout.CENTER);
        p.add(buildButtons(), BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildButtons() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        p.setBackground(GREEN_LIGHT);

        JButton btnAdd    = makeBtn("Add Agent",    new Color(56, 142, 60));
        JButton btnUpdate = makeBtn("Update Agent", new Color(30, 100, 170));
        JButton btnRemove = makeBtn("Remove Agent", new Color(198, 40, 40));
        JButton btnClear  = makeBtn("Clear Form",   new Color(100, 100, 100));

        btnAdd.addActionListener(e    -> addAgent());
        btnUpdate.addActionListener(e -> updateAgent());
        btnRemove.addActionListener(e -> removeAgent());
        btnClear.addActionListener(e  -> clearForm());

        p.add(btnAdd);
        p.add(btnUpdate);
        p.add(btnRemove);
        p.add(btnClear);
        return p;
    }

    private JPanel buildFormArea() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(Color.WHITE);
        outer.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(ACCENT, 1), "Agent Details"));

        JPanel grid = new JPanel(new GridLayout(3, 4, 10, 8));
        grid.setBackground(Color.WHITE);
        grid.setBorder(new EmptyBorder(10, 12, 10, 12));

        txtName         = new JTextField();
        txtPhone        = new JTextField();
        txtEmail        = new JTextField();
        txtVehiclePlate = new JTextField();
        cmbVehicleType  = new JComboBox<>(VEHICLE_TYPES);
        cmbStatus       = new JComboBox<>(STATUSES);

        grid.add(makeLabel("Full Name:"));    grid.add(txtName);
        grid.add(makeLabel("Phone:"));        grid.add(txtPhone);
        grid.add(makeLabel("Email:"));        grid.add(txtEmail);
        grid.add(makeLabel("Vehicle Type:")); grid.add(cmbVehicleType);
        grid.add(makeLabel("Plate No.:"));    grid.add(txtVehiclePlate);
        grid.add(makeLabel("Status:"));       grid.add(cmbStatus);

        outer.add(grid, BorderLayout.CENTER);
        return outer;
    }

    private void addAgent() {
        if (!isFormValid()) return;

        DeliveryAgent a = new DeliveryAgent(0,
                txtName.getText().trim(),
                txtPhone.getText().trim(),
                txtEmail.getText().trim(),
                (String) cmbVehicleType.getSelectedItem(),
                txtVehiclePlate.getText().trim().toUpperCase(),
                (String) cmbStatus.getSelectedItem());

        agentStore.addAgent(a);
        refreshTable();
        clearForm();
        JOptionPane.showMessageDialog(this, "Agent added successfully!", "Success",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateAgent() {
        int row = agentTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an agent to update.");
            return;
        }
        if (!isFormValid()) return;

        int id = (int) tableModel.getValueAt(row, 0);
        DeliveryAgent a = agentStore.findById(id);
        if (a != null) {
            a.setName(txtName.getText().trim());
            a.setPhone(txtPhone.getText().trim());
            a.setEmail(txtEmail.getText().trim());
            a.setVehicleType((String) cmbVehicleType.getSelectedItem());
            a.setVehiclePlate(txtVehiclePlate.getText().trim().toUpperCase());
            a.setStatus((String) cmbStatus.getSelectedItem());
            agentStore.updateAgent(a); 
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Agent updated successfully!", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void removeAgent() {
        int row = agentTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an agent to remove.");
            return;
        }
        int    id   = (int)    tableModel.getValueAt(row, 0);
        String name = (String) tableModel.getValueAt(row, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Remove agent \"" + name + "\"?", "Confirm Remove",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            agentStore.removeAgent(id);
            refreshTable();
            clearForm();
        }
    }

    private void fillFormFromSelection() {
        int row = agentTable.getSelectedRow();
        if (row < 0) return;
        txtName.setText(        (String) tableModel.getValueAt(row, 1));
        txtPhone.setText(       (String) tableModel.getValueAt(row, 2));
        txtEmail.setText(       (String) tableModel.getValueAt(row, 3));
        cmbVehicleType.setSelectedItem(  tableModel.getValueAt(row, 4));
        txtVehiclePlate.setText((String) tableModel.getValueAt(row, 5));
        cmbStatus.setSelectedItem(       tableModel.getValueAt(row, 6));
    }

    private void clearForm() {
        txtName.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        txtVehiclePlate.setText("");
        cmbVehicleType.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
        agentTable.clearSelection();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (DeliveryAgent a : agentStore.getAgents()) {
            tableModel.addRow(new Object[]{
                a.getId(), a.getName(), a.getPhone(), a.getEmail(),
                a.getVehicleType(), a.getVehiclePlate(), a.getStatus()
            });
        }
    }

    private boolean isFormValid() {
        if (txtName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name is required."); return false;
        }
        if (txtPhone.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Phone is required."); return false;
        }
        if (txtVehiclePlate.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vehicle plate is required."); return false;
        }
        return true;
    }

    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        return l;
    }

    private JButton makeBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 14, 8, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}