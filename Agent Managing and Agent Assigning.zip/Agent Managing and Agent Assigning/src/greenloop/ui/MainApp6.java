package greenloop.ui;

import javax.swing.*;
import java.awt.*;

public class MainApp6 extends JFrame {

    public MainApp6() {
        setTitle("GreenLoop – Task 6: Assign Delivery Agents to Orders");
        setSize(1100, 680);
        setMinimumSize(new Dimension(900, 550));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(new AssignDeliveryPanel());
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new MainApp6().setVisible(true));
    }
}