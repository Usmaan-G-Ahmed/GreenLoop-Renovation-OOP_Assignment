package greenloop.ui;

import greenloop.data.AgentStore;
import greenloop.data.OrderStore;
import greenloop.model.DeliveryAgent;
import greenloop.model.Order;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AssignDeliveryPanel extends JPanel {

    private AgentStore agentStore = AgentStore.getInstance();
    private OrderStore orderStore = OrderStore.getInstance();

    private DefaultTableModel tableModel;
    private JTable ordersTable;

    private JComboBox<String> cmbAgent;
    private JComboBox<String> cmbStatus;
    private JLabel lblOrderInfo;

    private static final String[] STATUSES = {"Pending", "Assigned", "Dispatched", "Delivered"};

    private static final Color GREEN_DARK  = new Color(34, 85, 34);
    private static final Color GREEN_LIGHT = new Color(230, 245, 230);
    private static final Color ACCENT      = new Color(56, 142, 60);

    public AssignDeliveryPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(GREEN_LIGHT);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTable(),  BorderLayout.CENTER);
        add(buildForm(),   BorderLayout.SOUTH);

        refreshTable();
        refreshAgentCombo();
    }

    // ── Header ───────────────────────────────────────────────────

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(GREEN_DARK);
        p.setBorder(new EmptyBorder(12, 16, 12, 16));

        JLabel title = new JLabel("Assign Delivery Agents to Orders");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        p.add(title, BorderLayout.WEST);
        return p;
    }

    // ── Orders Table ─────────────────────────────────────────────

    private JPanel buildTable() {
        String[] cols = {"Order ID", "Client", "Product", "Qty", "Total (Rs.)", "Status", "Assigned Agent"};

        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        ordersTable = new JTable(tableModel);
        ordersTable.setRowHeight(26);
        ordersTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        ordersTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        ordersTable.getTableHeader().setBackground(ACCENT);
        ordersTable.getTableHeader().setForeground(Color.WHITE);
        ordersTable.setSelectionBackground(new Color(178, 223, 178));

        // When user clicks a row fill the form
        ordersTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) fillFormFromSelection();
        });

        JScrollPane scroll = new JScrollPane(ordersTable);
        scroll.setBorder(BorderFactory.createTitledBorder("Client Orders"));

        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(GREEN_LIGHT);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── Assignment Form ──────────────────────────────────────────

    private JPanel buildForm() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(Color.WHITE);
        outer.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(ACCENT, 1), "Assign Delivery"));

        // Form fields
        JPanel grid = new JPanel(new GridLayout(3, 2, 10, 8));
        grid.setBackground(Color.WHITE);
        grid.setBorder(new EmptyBorder(10, 12, 10, 12));

        lblOrderInfo = new JLabel("Select an order from the table");
        cmbAgent     = new JComboBox<>();
        cmbStatus    = new JComboBox<>(STATUSES);

        grid.add(makeLabel("Selected Order:")); grid.add(lblOrderInfo);
        grid.add(makeLabel("Assign Agent:"));   grid.add(cmbAgent);
        grid.add(makeLabel("Status:"));         grid.add(cmbStatus);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        btnPanel.setBackground(Color.WHITE);

        JButton btnAssign   = makeBtn(" Assign Agent",  ACCENT);
        JButton btnUnassign = makeBtn(" Unassign Agent", new Color(198, 40, 40));

        btnAssign.addActionListener(e   -> assignAgent());
        btnUnassign.addActionListener(e -> unassignAgent());

        btnPanel.add(btnAssign);
        btnPanel.add(btnUnassign);

        outer.add(grid,     BorderLayout.CENTER);
        outer.add(btnPanel, BorderLayout.SOUTH);
        return outer;
    }

    // ── Logic ────────────────────────────────────────────────────

    private void fillFormFromSelection() {
        int row = ordersTable.getSelectedRow();
        if (row < 0) return;

        int orderId = (int) tableModel.getValueAt(row, 0);
        Order order = orderStore.findById(orderId);
        if (order == null) return;

        lblOrderInfo.setText("Order #" + order.getOrderId()
                + " — " + order.getClientName()
                + " | " + order.getProduct()
                + " x" + order.getQuantity());

        cmbStatus.setSelectedItem(order.getDeliveryStatus());

        // Pre select assigned agent if any
        if (order.getAssignedAgentId() != null) {
            for (int i = 0; i < cmbAgent.getItemCount(); i++) {
                if (cmbAgent.getItemAt(i).startsWith("[" + order.getAssignedAgentId() + "]")) {
                    cmbAgent.setSelectedIndex(i);
                    break;
                }
            }
        } else {
            cmbAgent.setSelectedIndex(0);
        }
    }

    private void assignAgent() {
        int row = ordersTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an order first.");
            return;
        }

        int orderId = (int) tableModel.getValueAt(row, 0);
        Order order = orderStore.findById(orderId);
        if (order == null) return;

        String agentEntry = (String) cmbAgent.getSelectedItem();
        if (agentEntry == null || agentEntry.equals("-- No Agent --")) {
            JOptionPane.showMessageDialog(this, "Please select an agent.");
            return;
        }

        // Get agent ID from "[ID] Name..."
        int agentId = Integer.parseInt(agentEntry.replaceAll("\\[(\\d+)\\].*", "$1"));
        DeliveryAgent agent = agentStore.findById(agentId);
        if (agent == null) return;

        // Update order
        String newStatus = (String) cmbStatus.getSelectedItem();
        order.setAssignedAgentId(agentId);
        order.setDeliveryStatus(newStatus);
        orderStore.updateOrder(order);

        // Update agent status
        if ("Assigned".equals(newStatus) || "Dispatched".equals(newStatus)) {
            agent.setStatus("On Delivery");
        } else if ("Delivered".equals(newStatus)) {
            agent.setStatus("Available");
        }
        agentStore.updateAgent(agent);

        JOptionPane.showMessageDialog(this, "Order #" + orderId
                + " assigned to " + agent.getName() + " successfully!", "Success",
                JOptionPane.INFORMATION_MESSAGE);

        refreshTable();
    }

    private void unassignAgent() {
        int row = ordersTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an order first.");
            return;
        }

        int orderId = (int) tableModel.getValueAt(row, 0);
        Order order = orderStore.findById(orderId);
        if (order == null) return;

        if (order.getAssignedAgentId() == null) {
            JOptionPane.showMessageDialog(this, "This order has no assigned agent.");
            return;
        }

        // Reset agent status to Available
        DeliveryAgent agent = agentStore.findById(order.getAssignedAgentId());
        if (agent != null) {
            agent.setStatus("Available");
            agentStore.updateAgent(agent);
        }

        // Reset order
        order.setAssignedAgentId(null);
        order.setDeliveryStatus("Pending");
        orderStore.updateOrder(order);

        JOptionPane.showMessageDialog(this, "Order #" + orderId
                + " unassigned successfully!", "Success",
                JOptionPane.INFORMATION_MESSAGE);

        refreshTable();
    }

    // ── Helpers ──────────────────────────────────────────────────

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Order o : orderStore.getOrders()) {
            String agentName = "—";
            if (o.getAssignedAgentId() != null) {
                DeliveryAgent a = agentStore.findById(o.getAssignedAgentId());
                if (a != null) agentName = a.getName();
            }
            tableModel.addRow(new Object[]{
                o.getOrderId(), o.getClientName(), o.getProduct(),
                o.getQuantity(), String.format("%.2f", o.getTotalAmount()),
                o.getDeliveryStatus(), agentName
            });
        }
    }

    private void refreshAgentCombo() {
        cmbAgent.removeAllItems();
        cmbAgent.addItem("-- No Agent --");
        for (DeliveryAgent a : agentStore.getAgents()) {
            cmbAgent.addItem("[" + a.getId() + "] " + a.getName()
                    + " (" + a.getVehicleType() + ")");
        }
    }

    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        return l;
    }

    private JButton makeBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 14, 8, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}