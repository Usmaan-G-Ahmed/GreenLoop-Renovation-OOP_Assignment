package greenloop.model;

public class Order {

    private int orderId;
    private String clientName;
    private String product;
    private int quantity;
    private double totalAmount;
    private String deliveryStatus;
    private Integer assignedAgentId;

    // Constructor
    public Order(int orderId, String clientName, String product,int quantity, double totalAmount) {
        this.orderId = orderId;
        this.clientName = clientName;
        this.product = product;
        this.quantity = quantity;
        this.totalAmount = totalAmount;
        this.deliveryStatus = "Pending";
        this.assignedAgentId = null;
    }

    // Getters
    public int getOrderId()             { return orderId; }
    public String getClientName()       { return clientName; }
    public String getProduct()          { return product; }
    public int getQuantity()            { return quantity; }
    public double getTotalAmount()      { return totalAmount; }
    public String getDeliveryStatus()   { return deliveryStatus; }
    public Integer getAssignedAgentId() { return assignedAgentId; }

    // Setters
    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }
    public void setAssignedAgentId(Integer assignedAgentId) {
        this.assignedAgentId = assignedAgentId;
    }
}