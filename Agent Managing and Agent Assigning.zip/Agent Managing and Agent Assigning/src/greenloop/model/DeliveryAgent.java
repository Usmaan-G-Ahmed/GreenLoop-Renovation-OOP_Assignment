package greenloop.model;

public class DeliveryAgent{
    

    private int id;
    private String name;
    private String phone;
    private String email;
    private String vehicleType;
    private String vehiclePlate;
    private String status;

    public DeliveryAgent(int id, String name, String phone, String email, String vehicleType, String vehiclePlate, String status){
        
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.vehicleType = vehicleType;
        this.vehiclePlate = vehiclePlate;
        this.status = status;
    }

    //Getters 
    public int getId(){
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail(){
        return email;
    } 

    public String getVehicleType(){
        return vehicleType;
    }

    public String getVehiclePlate(){
        return vehiclePlate;
    }

    public String getStatus (){
        return status;
    }

    //setters 

    public void setName(String name){
        this.name = name;
    }

    public void setPhone(String phone){
        this.phone = phone ;
    }

    public void setEmail (String email ){
        this.email = email;
    }

    public void setVehicleType(String vehicleType){
        this.vehicleType = vehicleType;
    }

    public void setVehiclePlate( String vehiclePlate){
        this.vehiclePlate = vehiclePlate;
    }

    public void setStatus ( String status){
        this.status = status;
    }
}
